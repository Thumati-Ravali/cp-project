/* Multi Agent Traveller Planner - backend API client */
(function () {
  'use strict';
  const API_BASE = (window.MATP_API_BASE || '/api').replace(/\/$/, '');
  const tokenKey = 'matp_token';
  async function request(path, options = {}) {
    const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
    const token = localStorage.getItem(tokenKey);
    if (token) headers.Authorization = 'Bearer ' + token;
    const response = await fetch(API_BASE + path, { ...options, headers });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(payload.message || 'Backend request failed (' + response.status + ')');
    return payload;
  }
  window.TravellerAPI = {
    signup: data => request('/auth/signup', { method: 'POST', body: JSON.stringify(data) }),
    login: data => request('/auth/login', { method: 'POST', body: JSON.stringify(data) }),
    forgot: data => request('/auth/forgot-password', { method: 'POST', body: JSON.stringify(data) }),
    securityQuestion: email => request('/auth/security-question?email=' + encodeURIComponent(email)),
    changePassword: data => request('/auth/change-password', { method: 'POST', body: JSON.stringify(data) }),
    saveTrip: (trip, total) => request('/trips', { method: 'POST', body: JSON.stringify({ trip, total }) }),
    getTrips: () => request('/trips'),
    deleteTrip: id => request('/trips/' + encodeURIComponent(id), { method: 'DELETE' }),
    clearToken: () => localStorage.removeItem(tokenKey),
    setToken: token => localStorage.setItem(tokenKey, token)
  };
})();
