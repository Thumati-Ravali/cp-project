/* Multi Agent Traveller Planner - application logic (no build step, runs from index.html) */
(function () {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const fmt = n => '₹' + Math.round(n).toLocaleString('en-IN');
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const mem = {};
  const store = {
    get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (e) { return k in mem ? mem[k] : d; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { mem[k] = v; } },
    del(k) { try { localStorage.removeItem(k); } catch (e) { delete mem[k]; } }
  };
  function toast(msg) {
    const t = $('#toast'); t.textContent = msg; t.classList.remove('hide');
    clearTimeout(toast.h); toast.h = setTimeout(() => t.classList.add('hide'), 2600);
  }

  /* ---------- auth ---------- */
  async function hashPw(pw, salt) {
    const data = salt + ':' + pw;
    if (window.crypto && crypto.subtle) {
      try { const b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(data)); return [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, '0')).join(''); } catch (e) { /* fall through */ }
    }
    let h = 5381; for (const ch of data) h = ((h << 5) + h + ch.charCodeAt(0)) >>> 0; return 'x' + h.toString(16);
  }
  const salt = () => Math.random().toString(36).slice(2) + Date.now().toString(36);
  const users = () => store.get('stp_users', {});
  const emailOk = e => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e);
  function strength(pw) {
    let s = 0; if (pw.length >= 8) s++; if (/[a-z]/.test(pw) && /[A-Z]/.test(pw)) s++; if (/\d/.test(pw)) s++; if (/[^A-Za-z0-9]/.test(pw)) s++; if (pw.length >= 12) s++;
    return Math.min(s, 4);
  }
  function pwProblem(pw) {
    if (pw.length < 8) return 'Password must be at least 8 characters.';
    if (!/[A-Za-z]/.test(pw) || !/\d/.test(pw)) return 'Password needs at least one letter and one number.';
    return '';
  }
  const QUESTIONS = ['What was the name of your first school?', 'What is your favourite place to travel?', 'What is your pet\'s name?', 'In which city were you born?'];
  let authMode = 'login';
  let user = null, trip = null;

  function authHTML() {
    const pwField = (id, label, ph) => `<div class="f pw"><label for="${id}">${label}</label><input id="${id}" type="password" autocomplete="${id.includes('new') || id === 'sp' ? 'new-password' : 'current-password'}" placeholder="${ph || ''}"><button type="button" class="eye" data-act="eye" data-t="${id}" aria-label="Show or hide password">👁</button></div>`;
    let form = '';
    if (authMode === 'login') {
      form = `<form data-form="login" novalidate>
        <div class="f"><label for="le">Email</label><input id="le" type="email" autocomplete="email" placeholder="you@example.com"></div>
        ${pwField('lp', 'Password', 'Your password')}
        <div class="err" id="aerr"></div>
        <button class="btn" style="width:100%;justify-content:center">Log in</button>
        <p class="small" style="text-align:center"><a href="#" data-act="mode" data-m="forgot">Forgot password?</a></p></form>`;
    } else if (authMode === 'signup') {
      form = `<form data-form="signup" novalidate>
        <div class="f"><label for="sn">Full name</label><input id="sn" autocomplete="name" placeholder="Your name"></div>
        <div class="f"><label for="se">Email</label><input id="se" type="email" autocomplete="email" placeholder="you@example.com"></div>
        ${pwField('sp', 'Set a password', 'At least 8 characters, letters and numbers')}
        <div class="meter" style="margin:-6px 0 12px"><i id="meter"></i></div>
        ${pwField('sc', 'Confirm password', 'Type it again')}
        <div class="f"><label for="sq">Security question (used to reset a forgotten password)</label><select id="sq">${QUESTIONS.map(q => `<option>${esc(q)}</option>`).join('')}</select></div>
        <div class="f"><label for="sa">Your answer</label><input id="sa" placeholder="Answer"></div>
        <div class="err" id="aerr"></div>
        <button class="btn" style="width:100%;justify-content:center">Create account</button></form>`;
    } else {
      form = `<form data-form="forgot" novalidate>
        <h3>Set a new password</h3>
        <div class="f"><label for="fe">Email</label><input id="fe" type="email" placeholder="you@example.com"></div>
        <div class="f"><label id="fql" for="fa">Security question</label><input id="fa" placeholder="Click Next to see your question"></div>
        ${pwField('fp-new', 'New password', 'At least 8 characters, letters and numbers')}
        ${pwField('fc-new', 'Confirm new password', '')}
        <div class="err" id="aerr"></div>
        <div class="row"><button type="button" class="btn ghost" data-act="showq">Show my question</button><button class="btn">Set password</button></div>
        <p class="small"><a href="#" data-act="mode" data-m="login">Back to login</a></p></form>`;
    }
    return `<section class="auth-hero">
        <a class="logo" href="#/home"><b>✈</b>Multi Agent Traveller Planner</a>
        <h1 style="margin-top:28px">Plan a budget-friendly trip in minutes</h1>
        <ul><li>📍 Destinations in India and around the world, with photos, fees and timings</li><li>🗺️ Live map and day-wise route with a Google Maps link</li><li>🏨 Budget hotels, food, guides and transport options in one place</li><li>💰 A live budget that tells you if you are within limit</li></ul>
        
      </section>
      <section class="auth-side"><div class="auth-card">
        ${authMode === 'forgot' ? '' : `<div class="tabs"><button class="${authMode === 'login' ? 'on' : ''}" data-act="mode" data-m="login">Log in</button><button class="${authMode === 'signup' ? 'on' : ''}" data-act="mode" data-m="signup">Sign up</button></div>`}
        ${form}
        <p class="small muted" style="margin-top:18px">Accounts are securely stored by the backend. Passwords are hashed before saving.</p>
      </div></section>`;
  }
  function showAuth() {
    $('#app').classList.add('hide'); const a = $('#auth'); a.classList.remove('hide'); a.innerHTML = authHTML();
    const sp = $('#sp'); if (sp) sp.addEventListener('input', () => { const m = $('#meter'); const s = strength(sp.value); m.style.width = (s * 25) + '%'; m.style.background = ['#dc2626', '#dc2626', '#f59e0b', '#84cc16', '#16a34a'][s]; });
  }
  const setErr = m => { const e = $('#aerr'); if (e) e.textContent = m; };

  async function doSignup() {
    const name = $('#sn').value.trim(), email = $('#se').value.trim().toLowerCase(), pw = $('#sp').value, c = $('#sc').value, q = $('#sq').value, a = $('#sa').value.trim();
    if (name.length < 2) return setErr('Please enter your name.');
    if (!emailOk(email)) return setErr('Please enter a valid email.');
    const pp = pwProblem(pw); if (pp) return setErr(pp);
    if (pw !== c) return setErr('Passwords do not match.');
    if (a.length < 2) return setErr('Please answer the security question.');
    try {
      const result = await TravellerAPI.signup({ name, email, password: pw, securityQuestion: q, securityAnswer: a });
      TravellerAPI.setToken(result.token);
      const u = users(); u[email] = { name, created: Date.now(), serverAccount: true }; store.set('stp_users', u);
      user = { email, name }; trip = store.get('stp_trip_' + email, null) || defaultTrip();
      store.set('stp_session', email); go('#/home'); toast('Welcome, ' + name + '! Your account is ready.');
    } catch (err) { setErr(err.message + (location.protocol === 'file:' ? ' Start the backend and open the site through http://localhost:5000.' : '')); }
  }
  async function doLogin() {
    const email = $('#le').value.trim().toLowerCase(), pw = $('#lp').value;
    if (!emailOk(email) || !pw) return setErr('Enter your email and password.');
    try {
      const result = await TravellerAPI.login({ email, password: pw });
      TravellerAPI.setToken(result.token);
      const u = users(); u[email] = { ...(u[email] || {}), name: result.user.name, serverAccount: true }; store.set('stp_users', u);
      user = { email, name: result.user.name }; trip = store.get('stp_trip_' + email, null) || defaultTrip();
      store.set('stp_session', email);
      try { const remote = await TravellerAPI.getTrips(); if (remote.trips) store.set(tripsKey(), remote.trips); } catch (_) {}
      go('#/home');
    } catch (err) { setErr(err.message + (location.protocol === 'file:' ? ' Start the backend and open the site through http://localhost:5000.' : '')); }
  }
  async function showQ() {
    const email = $('#fe').value.trim().toLowerCase();
    if (!emailOk(email)) return setErr('Enter a valid email address first.');
    try { const result = await TravellerAPI.securityQuestion(email); setErr(''); $('#fql').textContent = result.securityQuestion; $('#fa').focus(); }
    catch (err) { setErr(err.message); }
  }
  async function doForgot() {
    const email = $('#fe').value.trim().toLowerCase(), ans = $('#fa').value.trim(), pw = $('#fp-new').value, c = $('#fc-new').value;
    if (!emailOk(email)) return setErr('Enter a valid email address.');
    if (pw !== c) return setErr('Passwords do not match.');
    const pp = pwProblem(pw); if (pp) return setErr(pp);
    try { await TravellerAPI.forgot({ email, securityAnswer: ans, newPassword: pw }); authMode = 'login'; showAuth(); toast('Password updated. Please log in.'); }
    catch (err) { setErr(err.message); }
  }
  function login(email) {
    store.set('stp_session', email); user = { email, name: users()[email].name };
    trip = store.get('stp_trip_' + email, null) || defaultTrip();
    if (!location.hash || location.hash === '#/' ) go('#/home');
  }
  function logout() { store.del('stp_session'); if (window.TravellerAPI) TravellerAPI.clearToken(); user = null; trip = null; authMode = 'login'; location.hash = ''; render(); }

  /* ---------- trip state ---------- */
  function addDays(d, n) { const x = new Date(d); x.setDate(x.getDate() + n); return x; }
  const iso = d => d.toISOString().slice(0, 10);
  function defaultTrip() {
    return { from: 'Hyderabad', region: 'ap', date: iso(addDays(new Date(), 14)), travellers: 2, days: 3, budget: 25000,
      month: new Date(addDays(new Date(), 14)).toLocaleString('en', { month: 'long' }), group: 'Family', style: 'Normal', food: 'Both',
      mode: 'Train', selected: [], customPlaces: [], hotel: null, roomsSelected: 0, rest: null, photo: null, ref: null, bookedAt: null };
  }
  function go(h) { if (location.hash === h) render(); else location.hash = h; }
  const saveTrip = () => { if (user) { store.set('stp_trip_' + user.email, trip); if (localStorage.getItem('matp_token')) TravellerAPI.saveTrip(trip, calc().total).catch(err => console.warn('Cloud trip save failed:', err.message)); } };
  const REG = id => REGIONS.find(r => r.id === id);
  const PLACE = id => { for (const r of REGIONS) { const p = r.places.find(x => x.id === id); if (p) return p; } return (trip.customPlaces || []).find(x => x.id === id) || null; };
  const CITY = n => START_CITIES.find(c => c.n === n) || START_CITIES[0];
  const rad = x => x * Math.PI / 180;
  function hav(a, b) {
    const dLat = rad(b.lat - a.lat), dLng = rad(b.lng - a.lng);
    const h = Math.sin(dLat / 2) ** 2 + Math.cos(rad(a.lat)) * Math.cos(rad(b.lat)) * Math.sin(dLng / 2) ** 2;
    return 6371 * 2 * Math.asin(Math.sqrt(h));
  }
  function autoPick() {
    const r = REG(trip.region); const n = Math.min(r.places.length, +trip.days + 1);
    trip.selected = r.places.slice(0, n).map(p => p.id);
  }
  function ordered() {
    let cur = CITY(trip.from); const rest = trip.selected.map(PLACE).filter(Boolean); const out = [];
    while (rest.length) { let bi = 0, bd = 1e12; rest.forEach((p, i) => { const d = hav(cur, p); if (d < bd) { bd = d; bi = i; } }); const p = rest.splice(bi, 1)[0]; out.push(p); cur = p; }
    return out;
  }
  const routeCache = {};
  const rkey = ps => trip.from + '|' + ps.map(p => p.id).join(',');
  function legs(ps) {
    const c = routeCache[rkey(ps)]; if (c) return c.legs;
    const pts = [CITY(trip.from), ...ps]; const out = [];
    for (let i = 1; i < pts.length; i++) out.push(hav(pts[i - 1], pts[i]) * 1.3);
    return out;
  }
  function modeFares(d) {
    const r10 = x => Math.round(x / 10) * 10;
    return [
      { mode: 'Train', icon: '🚆', fare: r10(Math.max(150, d * 0.9)), hrs: d / 55, note: 'Sleeper, 3A, 2A and 1A classes' },
      { mode: 'Bus', icon: '🚌', fare: r10(Math.max(200, d * 1.4)), hrs: d / 45, note: 'AC/non-AC, seater and sleeper' },
      { mode: 'Flight', icon: '✈️', fare: r10(1800 + d * 3.5), hrs: 2.5 + d / 700, note: 'Compare airlines and live fares with booking partners' },
      { mode: 'Cab', icon: '🚕', fare: r10(Math.max(600, d * 11)), hrs: d / 55, perVehicle: true, note: 'Private cab; estimated per vehicle' },
      { mode: 'Scooter', icon: '🛵', fare: r10(Math.max(350, d * 3.2)), hrs: d / 30, perVehicle: true, note: 'Local scooter rental estimate; availability varies' },
      { mode: 'Bike rental', icon: '🚲', fare: r10(Math.max(250, d * 2.2)), hrs: d / 18, perVehicle: true, note: 'Local bicycle/Nextbike-style rental estimate' }
    ];
  }
  const HOTEL = id => { for (const r of REGIONS) { const h = r.hotels.find(x => x.id === id); if (h) return h; } return null; };
  const REST = id => { for (const r of REGIONS) { const h = r.rest.find(x => x.id === id); if (h) return h; } return null; };
  const PHOTO = id => { for (const r of REGIONS) { const h = r.photos.find(x => x.id === id); if (h) return h; } return null; };

  function calc() {
    const t = trip, ps = ordered(), lg = legs(ps), trav = +t.travellers, days = +t.days;
    const d0 = ps.length ? lg[0] : 0; const fares = modeFares(d0); const f = fares.find(m => m.mode === t.mode) || fares[0];
    const inter = ps.length ? (f.perVehicle ? f.fare * 2 : f.fare * trav * 2) : 0;
    const localKm = lg.slice(1).reduce((a, b) => a + b, 0);
    const local = ps.length ? Math.max(Math.round(localKm * 12), 300 * days) : 0;
    const rooms = Math.max(1, +(t.roomsSelected || Math.ceil(trav / 2))), hotel = t.hotel ? HOTEL(t.hotel) : null, rest = t.rest ? REST(t.rest) : null, photo = t.photo ? PHOTO(t.photo) : null;
    const stayRate = hotel ? hotel.price : TIERS[t.style].stay, mealRate = rest ? rest.price : TIERS[t.style].meal;
    const stay = days * rooms * stayRate, meals = trav * days * mealRate;
    const tickets = ps.reduce((a, p) => a + p.fee, 0) * trav, photoCost = photo ? photo.day : 0;
    const parts = [
      { k: 'Intercity travel', v: inter, c: '#0e9f94' }, { k: 'Local travel', v: local, c: '#38bdf8' },
      { k: 'Stay', v: stay, c: '#f59e0b' }, { k: 'Meals', v: meals, c: '#f0647a' },
      { k: 'Tickets', v: tickets, c: '#6366f1' }, { k: 'Photographer', v: photoCost, c: '#64748b' }
    ];
    const total = parts.reduce((a, b) => a + b.v, 0);
    return { ps, lg, fares, f, inter, local, localKm, rooms, hotel, rest, photo, stayRate, mealRate, stay, meals, tickets, photoCost, parts, total, per: total / trav, diff: t.budget - total, ok: total <= t.budget };
  }

  /* ---------- images (Wikipedia thumbnails, with graceful fallback) ---------- */
  const imgCache = store.get('stp_img', {});
  async function wikiImg(title) {
    if (title in imgCache && imgCache[title]) return imgCache[title];
    if (!navigator.onLine) return null;
    try {
      const ctl = new AbortController(); const to = setTimeout(() => ctl.abort(), 7000);
      const r = await fetch('https://en.wikipedia.org/api/rest_v1/page/summary/' + encodeURIComponent(title.replace(/ /g, '_')), { signal: ctl.signal }); clearTimeout(to);
      const j = await r.json(); const u = (j.thumbnail && j.thumbnail.source) || null;
      if (u) { imgCache[title] = u; store.set('stp_img', imgCache); } return u;
    } catch (e) { return null; }
  }
  function pic(title, label, emoji, cls, w) {
    const h = hashStr(title);
    return `<div class="pic ${cls || ''}" data-wiki="${esc(title)}" data-w="${w || 500}" style="--g1:hsl(${h % 360} 55% 40%);--g2:hsl(${(h + 60) % 360} 60% 22%)"><span>${emoji || '📍'}</span>${label ? `<div class="lbl">${esc(label)}</div>` : ''}</div>`;
  }
  function hydrate(root) {
    $$('[data-wiki]', root || document).forEach(async el => {
      const u = await wikiImg(el.dataset.wiki); if (!u) return;
      const big = u.replace(/\/\d+px-/, '/' + el.dataset.w + 'px-');
      const apply = src => { el.style.backgroundImage = `url("${src}")`; el.classList.add('has'); };
      const im = new Image(); im.onload = () => apply(big);
      im.onerror = () => { const i2 = new Image(); i2.onload = () => apply(u); i2.src = u; };
      im.src = big;
    });
  }

  /* ---------- views ---------- */
  const NAV = [['home', 'Home'], ['plan', 'Plan'], ['places', 'Places'], ['route', 'Map & Route'], ['stay', 'Stay & Food'], ['budget', 'Budget'], ['booking', 'Booking'], ['trips', 'My Trips']];
  const ui = { cat: 'All', q: '', view: 'list', tier: null };
  let after = null, map = null, mapLayers = null;

  function shell(page, inner) {
    const b = calc();
    return `<header class="top noprint"><div class="in">
      <a class="logo" href="#/home"><b>✈</b><span>Multi Agent Traveller Planner</span></a>
      <nav class="links">${NAV.map(([k, n]) => `<a href="#/${k}" class="${k === page ? 'on' : ''}">${n}</a>`).join('')}</nav>
      <a href="#/budget" class="pill ${b.ok ? 'ok' : 'bad'}" title="Estimated total vs budget">${fmt(b.total)} / ${fmt(trip.budget)}</a>
      <a href="#/profile" class="avatar" title="${esc(user.name)}">${esc(user.name.trim()[0].toUpperCase())}</a></div></header>
      <main>${inner}</main>
      <footer class="foot noprint">Multi Agent Traveller Planner<br>
      </footer>`;
  }

  function vHome() {
    const nPlaces = REGIONS.reduce((a, r) => a + r.places.length, 0);
    return `<div class="hero" style="position:relative;background:var(--navy)"><div class="pic" data-wiki="Taj Mahal" data-w="960" style="position:absolute;inset:0"></div><div style="position:absolute;inset:0;background:linear-gradient(110deg,rgba(11,31,58,.92),rgba(11,31,58,.35))"></div>
      <div style="position:relative"><span class="tag amber">Namaste, ${esc(user.name.split(' ')[0])}</span>
      <h1 style="margin-top:10px">Your whole trip, planned within budget.</h1>
      <p>Search destinations worldwide, choose transport and stays by budget, explore food and guides, and compare live booking options before you reserve.</p>
      <div class="row"><a class="btn alt" href="#/plan">Plan a new trip</a><a class="btn ghost" style="color:#fff;border-color:#fff" href="#/places">Explore places</a></div></div></div>
      <div class="card stats"><div class="stat"><b>${REGIONS.length}</b>Destinations</div><div class="stat"><b>${nPlaces}</b>Famous places</div><div class="stat"><b>${REGIONS.reduce((a, r) => a + r.hotels.length, 0)}</b>Hotels</div><div class="stat"><b>4</b>Transport modes</div></div>
      <h2>Popular destinations</h2><p class="muted">Tap a destination to start planning it.</p>
      <div class="grid4">${REGIONS.map(r => `<div class="region" data-act="pickregion" data-id="${r.id}">${pic(r.hero, '', r.emoji, '', 500)}<div class="body"><b>${esc(r.name)}</b><div class="small muted">${r.places.length} places · ${esc(r.cuisine)}</div></div></div>`).join('')}</div>
      <h2 style="margin-top:34px">How it works</h2>
      <div class="grid4">${[['📝', 'Plan', 'Fill one simple form with dates, people and budget.'], ['📍', 'Pick places', 'Choose from famous places with fees and timings.'], ['🗺️', 'See the route', 'A numbered map, day-wise plan and transport fares.'], ['🧾', 'Book', 'Get a reference number and a printable receipt.']].map(x => `<div class="card"><div style="font-size:2rem">${x[0]}</div><h3>${x[1]}</h3><p class="muted">${x[2]}</p></div>`).join('')}</div>`;
  }

  function vPlan() {
    const t = trip, opt = (arr, v) => arr.map(a => `<option ${a === v ? 'selected' : ''}>${esc(a)}</option>`).join('');
    const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    return `<div class="page-title"><div><h1>Plan your trip</h1><p class="muted">Eleven details are enough. Every page uses them and the budget updates live.</p></div></div>
    <form class="card" data-form="plan"><div class="grid3">
      <div><label>Starting city</label><select id="p-from">${START_CITIES.map(c => `<option ${c.n === t.from ? 'selected' : ''}>${c.n}</option>`).join('')}</select></div>
      <div><label>Destination country / region</label><select id="p-region">${REGIONS.map(r => `<option value="${r.id}" ${r.id === t.region ? 'selected' : ''}>${esc(r.name)}</option>`).join('')}</select><div class="small muted">Worldwide destinations are searchable under Places.</div></div>
      <div><label>Travel start date</label><input id="p-date" type="date" min="${iso(new Date())}" value="${t.date}"></div>
      <div><label>Number of travellers</label><input id="p-trav" type="number" min="1" max="20" value="${t.travellers}"></div>
      <div><label>Trip duration (days)</label><input id="p-days" type="number" min="1" max="15" value="${t.days}"></div>
      <div><label>Total budget (₹)</label><input id="p-budget" type="number" min="1000" step="500" value="${t.budget}"></div>
      <div><label>Preferred month</label><select id="p-month">${opt(months, t.month)}</select></div>
      <div><label>Group type</label><select id="p-group">${opt(['Solo', 'Friends', 'Family', 'Couple', 'Students'], t.group)}</select></div>
      <div><label>Budget category</label><select id="p-style">${opt(['Low Budget', 'Normal', 'Premium'], t.style)}</select></div>
      <div><label>Food preference</label><select id="p-food">${opt(['Both', 'Veg', 'Non-Veg'], t.food)}</select></div>
      <div><label>Preferred transport</label><select id="p-mode">${opt(['Train', 'Bus', 'Flight', 'Cab', 'Scooter', 'Bike rental'], t.mode)}</select></div>
    </div><div class="err" id="perr"></div>
    <div class="row"><button class="btn">Save and choose places →</button><span class="muted small">We will pre-select the top places for your number of days. You can change them.</span></div></form>`;
  }

  function placeCard(p) {
    const sel = trip.selected.includes(p.id);
    return `<div class="card flush place ${sel ? 'sel' : ''}">${pic(p.wiki, '', CAT_EMOJI[p.cat], '', 500)}
      <div class="body"><div class="meta"><span class="tag">${p.cat}</span><span class="tag amber">${p.fee ? fmt(p.fee) + ' entry' : 'Free entry'}</span></div>
      <h3>${esc(p.name)}</h3><div class="small muted">📍 ${esc(p.city)}</div><div class="small">${esc(p.desc)}</div>
      <div class="facts">🕘 ${esc(p.time)}<br>🌤️ Best: ${esc(p.season)} · ⏱️ about ${p.hrs} hrs</div>
      <div class="act"><button class="btn sm ${sel ? 'alt' : ''}" data-act="tog" data-id="${p.id}">${sel ? '✓ Added' : '+ Add to trip'}</button>
      <a class="btn sm ghost" target="_blank" rel="noopener" href="https://www.google.com/maps/search/?api=1&query=${p.lat},${p.lng}">Maps ↗</a></div></div></div>`;
  }
  function vPlaces() {
    const r = REG(trip.region); const list = [...r.places, ...(trip.customPlaces || [])].filter(p => (ui.cat === 'All' || p.cat === ui.cat) && (!ui.q || (p.name + p.city + p.desc).toLowerCase().includes(ui.q.toLowerCase())));
    const b = calc();
    return `<div class="page-title"><div><h1>🌍 Explore places worldwide</h1><p class="muted">Search by city, attraction, country, state or continent. The catalogue includes India and international highlights; global search can find additional places.</p></div><div class="spacer"></div>
      <select id="p-region2" style="width:auto">${REGIONS.map(x => `<option value="${x.id}" ${x.id === r.id ? 'selected' : ''}>${esc(x.name)}</option>`).join('')}</select>
      <button class="btn ghost sm" data-act="autopick">✨ Auto-pick for ${trip.days} days</button></div>
    <div class="card" style="margin-bottom:14px"><h3 style="margin-top:0">Search anywhere in the world</h3><div class="row"><input id="world-q" placeholder="Try Paris, France · Tokyo · Warangal · Europe..." style="flex:1;min-width:220px"><button class="btn" data-act="worldsearch">Find destination</button></div><p class="small muted" style="margin-bottom:0">Uses OpenStreetMap place search when online. Select a country/region above to see its curated catalogue; search results can be added directly to this trip.</p><div id="world-results"></div></div>
    <div class="row" style="margin-bottom:14px"><input id="q" placeholder="Filter this destination's places" value="${esc(ui.q)}" style="max-width:320px">
      ${CATEGORIES.map(c => `<span class="chip ${ui.cat === c ? 'on' : ''}" data-act="cat" data-c="${c}">${c}</span>`).join('')}<div class="spacer"></div>
      <span class="chip ${ui.view === 'list' ? 'on' : ''}" data-act="view" data-v="list">▦ Cards</span><span class="chip ${ui.view === 'map' ? 'on' : ''}" data-act="view" data-v="map">🗺️ Map</span></div>
    ${ui.view === 'map' ? '<div id="map" class="map"></div>' : (list.length ? `<div class="grid3">${list.map(placeCard).join('')}</div>` : '<div class="empty card">No places match your search.</div>')}
    <div class="card sticky-bar row noprint"><b>${trip.selected.length} place${trip.selected.length === 1 ? '' : 's'} selected</b><span class="muted">Estimated total ${fmt(b.total)} of ${fmt(trip.budget)}</span><div class="spacer"></div><a class="btn" href="#/route">See map and route →</a></div>`;
  }

  const hm = mins => { mins = Math.round(mins); const h = Math.floor(mins / 60) % 24, m = mins % 60; return String(h).padStart(2, '0') + ':' + String(m).padStart(2, '0'); };
  const dur = h => h < 1 ? Math.round(h * 60) + ' min' : Math.floor(h) + ' h ' + Math.round((h % 1) * 60) + ' min';
  function gmapsLink(ps) {
    const o = CITY(trip.from), last = ps[ps.length - 1], mid = ps.slice(0, -1).map(p => p.lat + ',' + p.lng).join('|');
    return `https://www.google.com/maps/dir/?api=1&origin=${o.lat},${o.lng}&destination=${last.lat},${last.lng}${mid ? '&waypoints=' + encodeURIComponent(mid) : ''}&travelmode=driving`;
  }
  function vRoute() {
    if (!trip.selected.length) return `<div class="card empty"><div style="font-size:3rem">🗺️</div><h2>No places selected yet</h2><p>Pick a few famous places and your route will appear here.</p><a class="btn" href="#/places">Choose places</a></div>`;
    return `<div class="page-title"><div><h1>Map and route</h1><p class="muted">Numbered stops from ${esc(trip.from)}, ordered to keep the driving short.</p></div></div>
      <div id="map" class="map"></div><div id="rinfo" style="margin-top:20px"></div>`;
  }
  function itinerary(b) {
    const per = Math.ceil(b.ps.length / trip.days) || 1; let html = '', idx = 0;
    for (let d = 0; d < trip.days; d++) {
      const chunk = b.ps.slice(idx, idx + per); const base = idx; idx += per;
      html += `<div class="day card"><h3><span>Day ${d + 1}</span> ${chunk.length ? esc(chunk.map(p => p.city).filter((v, i, a) => a.indexOf(v) === i).join(' · ')) : 'Leisure day'}</h3>`;
      if (!chunk.length) html += '<p class="muted">Rest, shop for souvenirs or explore nearby cafes. Add more places to fill this day.</p>';
      let t = 9 * 60;
      chunk.forEach((p, j) => {
        const km = b.lg[base + j]; const from = (base + j === 0) ? trip.from : b.ps[base + j - 1].name;
        const trv = km / 45 * 60; if (j > 0) t += trv;
        html += `<div class="stop">${pic(p.wiki, '', CAT_EMOJI[p.cat], 'th', 120)}<div class="t">${hm(t)}</div><div><b>${base + j + 1}. ${esc(p.name)}</b> <span class="tag">${p.cat}</span><div class="small muted">${Math.round(km)} km from ${esc(from)} · about ${p.hrs} hrs here · ${p.fee ? fmt(p.fee) : 'free'} entry</div></div></div>`;
        t += p.hrs * 60 + 30;
      });
      html += '</div>';
    }
    return html;
  }
  function renderRouteInfo(live) {
    const el = $('#rinfo'); if (!el) return; const b = calc(); const total = b.lg.reduce((a, x) => a + x, 0);
    const c = routeCache[rkey(b.ps)]; const hrs = c ? c.dur / 3600 : total / 45;
    el.innerHTML = `<div class="grid3" style="margin-bottom:16px"><div class="card stat"><b>${Math.round(total)} km</b>Total driving distance</div><div class="card stat"><b>${dur(hrs)}</b>Total driving time</div>
      <div class="card stat"><b>${b.ps.length}</b>Stops over ${trip.days} days</div></div>
      <div class="row" style="margin-bottom:16px"><span class="tag ${c ? '' : 'amber'}">${c ? '● Live road route (OpenStreetMap routing)' : '○ Estimated distances (routing service unreachable)'}</span><div class="spacer"></div>
      <a class="btn" target="_blank" rel="noopener" href="${gmapsLink(b.ps)}">Open in Google Maps ↗</a></div>
      <h2>Day-wise itinerary</h2>${itinerary(b)}
      <h2 style="margin-top:26px">Getting to ${esc(b.ps[0].city)} from ${esc(trip.from)} (${Math.round(b.lg[0])} km)</h2>
      <div class="card flush"><table><tr><th>Mode</th><th>Fare estimate (one way)</th><th>Time estimate</th><th>Round trip for ${trip.travellers}</th><th>Choose</th></tr>
      ${b.fares.map(m => `<tr class="${m.mode === trip.mode ? 'pick' : ''}"><td><b>${m.icon} ${m.mode}</b><div class="small muted">${m.note}</div></td><td>${fmt(m.fare)} ${m.perVehicle ? 'per vehicle' : 'per person'}</td><td>${dur(m.hrs)}</td><td><b>${fmt(m.perVehicle ? m.fare * 2 : m.fare * trip.travellers * 2)}</b></td><td><button class="btn sm ${m.mode === trip.mode ? '' : 'ghost'}" data-act="mode" data-m="${m.mode}">${m.mode === trip.mode ? '✓ Selected' : 'Select'}</button></td></tr>`).join('')}</table></div>
      <div class="card" style="margin-top:18px"><h2>Search real schedules and book</h2><p class="muted">Choose your date in the trip planner first. These links open providers for live schedules, seat/room inventory and current prices. This project does not yet have airline, railway or bus operator API credentials, so it does not claim that sample estimates are bookable.</p>
      <div class="grid3">
      <div><b>✈️ Flights</b><p class="small muted">Airlines may include IndiGo, Air India, Akasa Air and others. Compare departure/arrival times and fare classes.</p><a target="_blank" rel="noopener" href="https://www.google.com/travel/flights?q=${encodeURIComponent('Flights from '+trip.from+' to '+(b.ps[0] ? b.ps[0].city : REG(trip.region).name)+' on '+trip.date)}">Compare flights ↗</a><div class="small"><a target="_blank" rel="noopener" href="https://www.goindigo.in/">IndiGo ↗</a> · <a target="_blank" rel="noopener" href="https://www.airindia.com/">Air India ↗</a></div></div>
      <div><b>🚆 Trains</b><p class="small muted">Check train numbers, departure/arrival times, classes and seat availability.</p><a target="_blank" rel="noopener" href="https://www.irctc.co.in/nget/">Open IRCTC ↗</a><div class="small"><a target="_blank" rel="noopener" href="https://www.google.com/search?q=${encodeURIComponent('trains from '+trip.from+' to '+(b.ps[0] ? b.ps[0].city : REG(trip.region).name)+' on '+trip.date)}">Search train times ↗</a></div></div>
      <div><b>🚌 Buses</b><p class="small muted">Compare operators, boarding points and sleeper/seater options.</p><a target="_blank" rel="noopener" href="https://www.redbus.in/">Search buses ↗</a></div>
      <div><b>🚕 Cabs</b><p class="small muted">Compare point-to-point or full-day cab options.</p><a target="_blank" rel="noopener" href="https://www.google.com/maps">Explore cabs and routes ↗</a></div>
      <div><b>🛵 Scooters</b><p class="small muted">Local rental availability depends on destination and licence rules.</p><a target="_blank" rel="noopener" href="https://www.google.com/search?q=scooter+rentals+${encodeURIComponent(b.ps[0] ? b.ps[0].city : REG(trip.region).name)}">Find scooter rentals ↗</a></div>
      <div><b>🚲 Bike / Nextbike</b><p class="small muted">Check local cycle-share stations and rental terms.</p><a target="_blank" rel="noopener" href="https://www.google.com/search?q=bike+sharing+${encodeURIComponent(b.ps[0] ? b.ps[0].city : REG(trip.region).name)}">Find bike rentals ↗</a></div>
      </div></div>
      <div class="row" style="margin-top:18px"><a class="btn" href="#/stay">Next: stay and food →</a></div>`;
  }
  async function drawRoute() {
    if (typeof L === 'undefined') { $('#map').innerHTML = '<div class="empty">Map library could not be loaded.</div>'; return; }
    const b = calc(); const pts = [CITY(trip.from), ...b.ps];
    initMap($('#map'));
    const bounds = []; pts.forEach((p, i) => {
      const lat = p.lat, lng = p.lng; bounds.push([lat, lng]);
      L.marker([lat, lng], { icon: numIcon(i === 0 ? '🏠' : i, i === 0 ? 'start' : '') }).addTo(mapLayers).bindPopup(`<b>${esc(i === 0 ? trip.from + ' (start)' : p.name)}</b>${i ? '<br>' + esc(p.city) + ' · ' + (p.fee ? fmt(p.fee) : 'Free') : ''}`);
    });
    map.fitBounds(bounds, { padding: [40, 40] });
    const key = rkey(b.ps); const straight = () => L.polyline(bounds, { color: '#f59e0b', weight: 4, dashArray: '8 8' }).addTo(mapLayers);
    renderRouteInfo();
    if (routeCache[key]) { L.geoJSON(routeCache[key].geo, { style: { color: '#0e9f94', weight: 5 } }).addTo(mapLayers); return; }
    try {
      const ctl = new AbortController(); const to = setTimeout(() => ctl.abort(), 9000);
      const url = 'https://router.project-osrm.org/route/v1/driving/' + pts.map(p => p.lng + ',' + p.lat).join(';') + '?overview=full&geometries=geojson';
      const res = await fetch(url, { signal: ctl.signal }); clearTimeout(to); const j = await res.json();
      if (j.code !== 'Ok') throw new Error('route');
      const r0 = j.routes[0]; routeCache[key] = { legs: r0.legs.map(l => l.distance / 1000), geo: r0.geometry, dur: r0.duration };
      if (location.hash === '#/route' && map) { L.geoJSON(r0.geometry, { style: { color: '#0e9f94', weight: 5 } }).addTo(mapLayers); renderRouteInfo(); updatePill(); }
    } catch (e) { if (map) straight(); }
  }
  function initMap(el) {
    if (map) { map.remove(); map = null; }
    map = L.map(el, { scrollWheelZoom: false }).setView([22.5, 79], 5);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 18, attribution: '© OpenStreetMap contributors' }).addTo(map);
    mapLayers = L.layerGroup().addTo(map); setTimeout(() => map && map.invalidateSize(), 150);
  }
  const numIcon = (n, cls) => L.divIcon({ className: '', html: `<div class="num ${cls || ''}">${n}</div>`, iconSize: [30, 30], iconAnchor: [15, 15] });
  function drawPlacesMap() {
    if (typeof L === 'undefined') return; initMap($('#map')); const r = REG(trip.region); const bounds = [];
    [...r.places, ...(trip.customPlaces || [])].forEach(p => {
      const sel = trip.selected.includes(p.id); bounds.push([p.lat, p.lng]);
      L.marker([p.lat, p.lng], { icon: numIcon(sel ? '✓' : '+', sel ? '' : 'off') }).addTo(mapLayers)
        .bindPopup(`<b>${esc(p.name)}</b><br>${esc(p.city)} · ${p.fee ? fmt(p.fee) : 'Free'}<br><button class="btn sm" style="margin-top:6px" data-act="tog" data-id="${p.id}">${sel ? 'Remove from trip' : 'Add to trip'}</button>`);
    });
    map.fitBounds(bounds, { padding: [40, 40] });
  }

  function vStay() {
    const r = REG(trip.region), tier = ui.tier || trip.style; const hotels = r.hotels.filter(h => tier === 'All' || h.tier === tier);
    const rests = r.rest.filter(x => trip.food === 'Both' || (trip.food === 'Veg' ? x.type === 'Veg' : x.type !== 'Veg'));
    const b = calc();
    return `<div class="page-title"><div><h1>Stay, food and photographer</h1><p class="muted">Options for ${esc(r.name)}. Your choices change the budget immediately.</p></div></div>
    <h2>🏨 Hotels</h2><div class="row" style="margin-bottom:12px">${['All', 'Low Budget', 'Normal', 'Premium'].map(t => `<span class="chip ${tier === t ? 'on' : ''}" data-act="tier" data-t="${t}">${t}</span>`).join('')}<span class="muted small">Rate per room per night. ${b.rooms} room${b.rooms > 1 ? 's' : ''} for ${trip.travellers} travellers.</span></div>
    <div class="row" style="margin:10px 0 16px"><label for="room-count">Rooms to reserve</label><select id="room-count" style="max-width:130px">${[1,2,3,4,5,6,7,8,9,10].map(n => `<option value="${n}" ${n === b.rooms ? 'selected' : ''}>${n} room${n>1?'s':''}</option>`).join('')}</select><span class="small muted">Suggested: ${Math.ceil(trip.travellers/2)} room(s) for ${trip.travellers} guests. Room availability shown here is demo inventory.</span></div>
    <div class="grid2">${hotels.map(h => `<div class="card row"><div style="width:104px;flex-shrink:0">${pic(h.city + ' hotel', '', '🏨', '', 300)}</div><div style="flex:1"><b>${esc(h.name)}</b><div class="small muted">${esc(h.city)} · ⭐ ${h.rating} · Guest review score (sample)</div><div class="small muted">Sample review: Clean rooms, helpful staff and convenient location.</div><span class="tag ${h.tier === 'Premium' ? 'amber' : h.tier === 'Low Budget' ? 'sky' : ''}">${h.tier}</span><div class="small">Rooms available: ${h.availableRooms} (sample inventory) · confirm with hotel</div>${trip.hotel === h.id && b.rooms > h.availableRooms ? `<div class="small" style="color:#b45309">Selected ${b.rooms} rooms exceeds this sample inventory.</div>` : ''}<a class="small" target="_blank" rel="noopener" href="https://www.google.com/search?q=${encodeURIComponent('hotel ' + h.name + ' booking')}">Check live rates / reviews ↗</a></div><div style="text-align:right"><b>${fmt(h.price)}</b><div class="small muted">per night</div><button class="btn sm ${trip.hotel === h.id ? '' : 'ghost'}" data-act="hotel" data-id="${h.id}">${trip.hotel === h.id ? '✓ Selected' : 'Select'}</button></div></div>`).join('')}</div>
    <h2 style="margin-top:28px">🍽️ Restaurants <span class="muted small">(${esc(trip.food)} preference)</span></h2>
    <div class="grid2">${rests.map(x => `<div class="card row"><div style="width:104px;flex-shrink:0">${pic(x.type === 'Veg' ? 'Indian vegetarian thali' : 'Indian restaurant food', '', x.type === 'Veg' ? '🥗' : '🍽️', '', 300)}</div><div style="flex:1"><b>${esc(x.name)}</b><div class="small muted">${esc(x.cuisine)} · ⭐ ${x.rating}</div><span class="tag ${x.type === 'Veg' ? '' : x.type === 'Non-Veg' ? 'rose' : 'sky'}">${x.type}</span></div><div style="text-align:right"><b>${fmt(x.price)}</b><div class="small muted">per person per day</div><button class="btn sm ${trip.rest === x.id ? '' : 'ghost'}" data-act="rest" data-id="${x.id}">${trip.rest === x.id ? '✓ Selected' : 'Select'}</button></div></div>`).join('')}</div>
    <h2 style="margin-top:28px">📸 Photographers <span class="muted small">(optional)</span></h2>
    <div class="card" style="margin-top:22px"><h2>🧭 Local tour guide</h2><p class="muted">Ask a local guide about attractions, routes, timings and local customs. Contact below is a demonstration placeholder, not a verified guide booking.</p><div class="row"><div style="flex:1"><b>Destination local guide desk</b><div class="small muted">English · Hindi · Local language · Sample listing</div><div class="small">Guided city walk: estimate ₹800–₹1,500 per group</div></div><a class="btn ghost" target="_blank" rel="noopener" href="https://www.google.com/search?q=${encodeURIComponent('local tour guides ' + r.name + ' phone number')}">☎ Find guides to call ↗</a></div></div>
    <div class="grid2">${r.photos.map(x => `<div class="card row"><div style="flex:1"><b>${esc(x.name)}</b><div class="small muted">${esc(x.style)} · ⭐ ${x.rating}</div><div class="small">${fmt(x.hour)} per hour</div></div><div style="text-align:right"><b>${fmt(x.day)}</b><div class="small muted">full day</div><button class="btn sm ${trip.photo === x.id ? '' : 'ghost'}" data-act="photo" data-id="${x.id}">${trip.photo === x.id ? '✓ Selected' : 'Select'}</button></div></div>`).join('')}</div>
    <div class="card sticky-bar row noprint"><span>Estimated total <b>${fmt(b.total)}</b></span><div class="spacer"></div><a class="btn" href="#/budget">Next: budget →</a></div>`;
  }

  function vBudget() {
    const b = calc(), max = Math.max(...b.parts.map(p => p.v), 1), pct = Math.min(100, b.total / trip.budget * 100);
    return `<div class="page-title"><div><h1>Budget estimate</h1><p class="muted">Every number is explained below, so you always know where the money goes.</p></div></div>
    <div class="grid2"><div class="card"><div class="muted">Estimated total for ${trip.travellers} traveller${trip.travellers > 1 ? 's' : ''}, ${trip.days} days</div><div class="big">${fmt(b.total)}</div>
      <div class="bar" style="margin:10px 0"><i style="width:${pct}%;background:${b.ok ? '#16a34a' : '#dc2626'}"></i></div>
      <b style="color:${b.ok ? '#166534' : '#991b1b'}">${b.ok ? '✓ Within budget. ' + fmt(b.diff) + ' remaining' : '⚠ Over budget by ' + fmt(-b.diff)}</b>
      <div class="muted small">Budget ${fmt(trip.budget)} · ${fmt(b.per)} per person</div>
      <div class="row" style="margin-top:14px"><label style="margin:0">Change budget</label><input type="number" id="bud" value="${trip.budget}" min="1000" step="500" style="max-width:150px"></div>
      ${!b.ok ? '<p class="small" style="margin-bottom:0">💡 Tip: choose Normal style, Bus or Train, fewer places or fewer days to bring the cost down.</p>' : ''}</div>
      <div class="card">${b.parts.map(p => `<div class="brow"><span>${p.k}</span><div class="bar"><i style="width:${p.v / max * 100}%;background:${p.c}"></i></div><b>${fmt(p.v)}</b></div>`).join('')}</div></div>
    <h2 style="margin-top:26px">How it is calculated</h2>
    <div class="card"><table><tr><th>Part</th><th>Calculation</th><th>Amount</th></tr>
      <tr><td>Intercity travel</td><td>${esc(trip.mode)}, ${esc(trip.from)} to ${b.ps[0] ? esc(b.ps[0].city) : '-'} and back (${b.ps.length ? Math.round(b.lg[0]) : 0} km each way)</td><td>${fmt(b.inter)}</td></tr>
      <tr><td>Local travel</td><td>${Math.round(b.localKm)} km between places × ₹12 per km (minimum ₹300 per day)</td><td>${fmt(b.local)}</td></tr>
      <tr><td>Stay</td><td>${trip.days} nights × ${b.rooms} room(s) × ${fmt(b.stayRate)} ${b.hotel ? '(' + esc(b.hotel.name) + ')' : '(' + trip.style + ' average)'}</td><td>${fmt(b.stay)}</td></tr>
      <tr><td>Meals</td><td>${trip.travellers} × ${trip.days} days × ${fmt(b.mealRate)} ${b.rest ? '(' + esc(b.rest.name) + ')' : '(' + trip.style + ' average)'}</td><td>${fmt(b.meals)}</td></tr>
      <tr><td>Tickets</td><td>Entry fees ${fmt(b.ps.reduce((a, p) => a + p.fee, 0))} × ${trip.travellers} travellers</td><td>${fmt(b.tickets)}</td></tr>
      <tr><td>Photographer</td><td>${b.photo ? esc(b.photo.name) + ', full day' : 'Not selected'}</td><td>${fmt(b.photoCost)}</td></tr></table></div>
    <div class="row" style="margin-top:18px"><a class="btn ghost" href="#/stay">← Change stay</a><a class="btn" href="#/booking">Next: booking →</a></div>`;
  }

  const refNo = () => 'STAI-' + String(Math.floor(Math.random() * 1e8)).padStart(8, '0');
  function receipt(b) {
    const r = REG(trip.region); const end = iso(addDays(trip.date, trip.days - 1));
    return `<div class="receipt" id="receipt"><h2>Multi Agent Traveller Planner · Trip Receipt</h2><div class="ref">${trip.ref}</div>
      <table><tr><td>Traveller</td><td>${esc(user.name)} (${esc(user.email)})</td></tr>
      <tr><td>Trip</td><td>${esc(trip.from)} → ${esc(r.name)}</td></tr><tr><td>Dates</td><td>${trip.date} to ${end} (${trip.days} days)</td></tr>
      <tr><td>Travellers</td><td>${trip.travellers} · ${esc(trip.group)} · ${esc(trip.style)} style · ${esc(trip.food)}</td></tr>
      <tr><td>Places</td><td>${b.ps.map((p, i) => (i + 1) + '. ' + esc(p.name)).join('<br>')}</td></tr>
      <tr><td>Transport</td><td>${esc(trip.mode)} round trip: ${fmt(b.inter)}<br>Local travel: ${fmt(b.local)}</td></tr>
      <tr><td>Hotel</td><td>${b.hotel ? esc(b.hotel.name) + ', ' + esc(b.hotel.city) : trip.style + ' stay'}: ${fmt(b.stay)}</td></tr>
      <tr><td>Food</td><td>${b.rest ? esc(b.rest.name) : trip.style + ' meals'}: ${fmt(b.meals)}</td></tr>
      <tr><td>Entry tickets</td><td>${fmt(b.tickets)}</td></tr><tr><td>Photographer</td><td>${b.photo ? esc(b.photo.name) + ': ' + fmt(b.photoCost) : 'None'}</td></tr>
      <tr><td><b>Total</b></td><td><b>${fmt(b.total)}</b> (${fmt(b.per)} per person)</td></tr>
      <tr><td>Budget status</td><td>${b.ok ? 'Within budget, ' + fmt(b.diff) + ' remaining' : 'Over budget by ' + fmt(-b.diff)}</td></tr></table>
      <p class="small muted">Prepared on ${new Date(trip.bookedAt).toLocaleString('en-IN')}. This is a planning receipt with estimated costs; no payment has been taken.</p></div>`;
  }
  function vBooking() {
    const b = calc(); if (!b.ps.length) return `<div class="card empty"><h2>Choose places first</h2><a class="btn" href="#/places">Choose places</a></div>`;
    if (trip.ref) return `<div class="page-title"><div><h1>🎉 Trip confirmed</h1><p class="muted">Your trip plan is saved. Print the itinerary summary or find it later in My Trips. External transport/hotel reservations are not placed by this demo.</p></div></div>${receipt(b)}
      <div class="row noprint" style="justify-content:center;margin-top:18px"><button class="btn" data-act="print">🖨️ Print / save as PDF</button><a class="btn ghost" href="#/trips">My Trips</a><button class="btn ghost" data-act="newbook">Edit this plan</button></div>`;
    return `<div class="page-title"><div><h1>Review and confirm</h1><p class="muted">Review your itinerary and create a planning reference. Confirm and pay with the provider links for real reservations.</p></div></div>
    <div class="grid2"><div class="card"><h3>${esc(trip.from)} → ${esc(REG(trip.region).name)}</h3><p>${trip.date} · ${trip.days} days · ${trip.travellers} travellers · ${esc(trip.style)}</p>
      <ol>${b.ps.map(p => `<li><b>${esc(p.name)}</b>, ${esc(p.city)} <span class="muted">(${p.fee ? fmt(p.fee) : 'free'})</span></li>`).join('')}</ol>
      <p>🚆 ${esc(trip.mode)} · 🏨 ${b.hotel ? esc(b.hotel.name) : trip.style + ' stay'} · 🍽️ ${b.rest ? esc(b.rest.name) : trip.style + ' meals'} · 📸 ${b.photo ? esc(b.photo.name) : 'No photographer'}</p></div>
      <div class="card"><div class="muted">Total</div><div class="big">${fmt(b.total)}</div><b style="color:${b.ok ? '#166534' : '#991b1b'}">${b.ok ? '✓ Within budget, ' + fmt(b.diff) + ' left' : '⚠ Over budget by ' + fmt(-b.diff)}</b>
      <p class="muted small">No payment or external reservation is taken. This creates a trip-planning reference and printable summary.</p><button class="btn alt" data-act="confirm">Confirm and get receipt</button></div></div>`;
  }

  const tripsKey = () => 'stp_trips_' + user.email;
  function snapshot() { const b = calc(); const r = REG(trip.region); return { id: trip.ref || ('d' + Date.now()), ref: trip.ref, title: `${trip.from} → ${r.name} · ${trip.days} days`, created: Date.now(), total: b.total, trip: JSON.parse(JSON.stringify(trip)) }; }
  function persistTrip() {
    const all = store.get(tripsKey(), []); const s = snapshot(); const i = all.findIndex(x => x.id === s.id); if (i >= 0) all[i] = s; else all.unshift(s); store.set(tripsKey(), all);
    if (localStorage.getItem('matp_token')) TravellerAPI.saveTrip(trip, calc().total).catch(err => console.warn('Cloud trip save failed:', err.message));
  }
  function vTrips() {
    const all = store.get(tripsKey(), []);
    if (!all.length) return `<div class="card empty"><div style="font-size:3rem">🧳</div><h2>No saved trips yet</h2><p>Plan a trip and press Save, or confirm a booking.</p><a class="btn" href="#/plan">Plan a trip</a></div>`;
    return `<div class="page-title"><h1>My trips</h1></div><div class="grid2">${all.map(s => `<div class="card"><h3>${esc(s.title)}</h3><p class="muted small">${s.ref ? 'Ref ' + s.ref + ' · ' : 'Draft · '}Saved ${new Date(s.created).toLocaleDateString('en-IN')} · ${s.trip.travellers} travellers</p><div class="big" style="font-size:1.6rem">${fmt(s.total)}</div><div class="row" style="margin-top:10px"><button class="btn sm" data-act="open" data-id="${s.id}">Open</button><button class="btn sm danger" data-act="del" data-id="${s.id}">Delete</button></div></div>`).join('')}</div>`;
  }
  function vProfile() {
    return `<div class="page-title"><h1>My profile</h1></div><div class="grid2"><div class="card"><h3>${esc(user.name)}</h3><p class="muted">${esc(user.email)}</p>
      <div class="row"><button class="btn" data-act="logout">Log out</button><button class="btn ghost" data-act="clear">Clear saved trips</button></div></div>
      <form class="card" data-form="chpw" novalidate><h3>Change password</h3>
      <div class="f pw"><label for="cp0">Current password</label><input id="cp0" type="password" autocomplete="current-password"><button type="button" class="eye" data-act="eye" data-t="cp0">👁</button></div>
      <div class="f pw" style="margin-top:10px"><label for="cp1">New password</label><input id="cp1" type="password" autocomplete="new-password"><button type="button" class="eye" data-act="eye" data-t="cp1">👁</button></div>
      <div class="f" style="margin-top:10px"><label for="cp2">Confirm new password</label><input id="cp2" type="password" autocomplete="new-password"></div>
      <div class="err" id="perr"></div><button class="btn">Update password</button></form></div>`;
  }

  /* ---------- router ---------- */
  const VIEWS = { home: vHome, plan: vPlan, places: vPlaces, route: vRoute, stay: vStay, budget: vBudget, booking: vBooking, trips: vTrips, profile: vProfile };
  function render() {
    if (!user) { showAuth(); return; }
    $('#auth').classList.add('hide'); const app = $('#app'); app.classList.remove('hide');
    const page = (location.hash.replace('#/', '').split('?')[0]) || 'home'; const view = VIEWS[page] ? page : 'home';
    if (map) { map.remove(); map = null; }
    app.innerHTML = shell(view, VIEWS[view]()); window.scrollTo(0, 0);
    hydrate(app);
    if (view === 'route' && trip.selected.length) drawRoute();
    if (view === 'places' && ui.view === 'map') drawPlacesMap();
    document.title = 'Multi Agent Traveller Planner · ' + (NAV.find(n => n[0] === view) || ['', 'Account'])[1];
  }
  function refresh() { // re-render without scrolling to top
    const y = window.scrollY; render(); window.scrollTo(0, y);
  }
  function updatePill() {
    const p = $('.pill'); if (!p) return; const b = calc(); p.textContent = fmt(b.total) + ' / ' + fmt(trip.budget); p.className = 'pill ' + (b.ok ? 'ok' : 'bad');
  }
  function changed() { saveTrip(); updatePill(); }

  /* ---------- events ---------- */
  document.addEventListener('click', async e => {
    const a = e.target.closest('[data-act]'); if (!a) return; const act = a.dataset.act; const d = a.dataset;
    if (act === 'worldsearch') {
      const q = ($('#world-q') || {}).value?.trim(); const box = $('#world-results');
      if (!q) { toast('Enter a city, attraction, country or state'); return; }
      const continentMap = { europe: ['fr','it','ukg','ch'], asia: ['jp','ae','th','sg'], 'north america': ['us'], 'south america': ['br'], africa: ['za'], oceania: ['au'] };
      const continentKey = q.toLowerCase();
      if (continentMap[continentKey]) {
        if (box) box.innerHTML = '<p class="small muted">Explore curated countries in ' + esc(q) + ':</p>' + continentMap[continentKey].map(id => REG(id)).filter(Boolean).map(r => `<button class="btn sm ghost" style="margin:4px" data-act="pickregion" data-id="${r.id}">${r.emoji} ${esc(r.name)}</button>`).join('');
        return;
      }
      if (box) box.innerHTML = '<p class="small muted">Searching the world map…</p>';
      try {
        const url = 'https://nominatim.openstreetmap.org/search?format=jsonv2&limit=6&addressdetails=1&q=' + encodeURIComponent(q);
        const res = await fetch(url, { headers: { 'Accept-Language': 'en' } }); const hits = await res.json();
        if (!hits.length) { if (box) box.innerHTML = '<p class="small muted">No match found. Try a more specific place name.</p>'; return; }
        if (box) box.innerHTML = hits.map((h,i) => `<div class="row" style="justify-content:space-between;border-top:1px solid var(--line);padding:9px 0"><span class="small">${esc(h.display_name)}</span><button class="btn sm" data-act="addworld" data-lat="${h.lat}" data-lon="${h.lon}" data-name="${esc(h.name || q)}" data-address="${esc(h.display_name)}">Add to trip</button></div>`).join('');
      } catch (_) { if (box) box.innerHTML = '<p class="small muted">Global search needs an internet connection. You can still choose a listed country and destination.</p>'; }
      return;
    }
    if (act === 'addworld') {
      const id = 'world-' + Date.now();
      const address = d.address || d.name; const parts = address.split(',').map(x => x.trim());
      const city = parts.length > 1 ? parts[0] : d.name;
      const matchingRegion = REGIONS.find(r => address.toLowerCase().includes(r.name.toLowerCase()) || r.cities.some(c => c.toLowerCase() === city.toLowerCase()));
      if (matchingRegion && matchingRegion.id !== trip.region) { trip.region = matchingRegion.id; trip.selected = []; trip.customPlaces = []; trip.hotel = trip.rest = trip.photo = null; }
      const p = { id, region: trip.region, name: d.name, city, lat: +d.lat, lng: +d.lon, fee: 0, time: 'Check local opening hours', season: 'Varies by destination', cat: 'City', hrs: 2, desc: address, wiki: d.name };
      trip.customPlaces = trip.customPlaces || []; trip.customPlaces.push(p);
      if (!trip.selected.includes(id)) trip.selected.push(id);
      saveTrip(); refresh(); toast(d.name + ' added to your trip'); return;
    }
    if (act === 'mode' && a.closest('#auth')) { e.preventDefault(); authMode = d.m; showAuth(); return; }
    if (act === 'mode' && a.closest('#auth') === null && d.m && ['Train', 'Bus', 'Flight', 'Cab', 'Scooter', 'Bike rental'].includes(d.m)) { trip.mode = d.m; changed(); renderRouteInfo(); return; }
    if (act === 'eye') { const i = $('#' + d.t); i.type = i.type === 'password' ? 'text' : 'password'; return; }
    if (act === 'showq') { showQ(); return; }
    if (act === 'pickregion') { if (trip.region !== d.id) { trip.region = d.id; trip.hotel = trip.rest = trip.photo = null; autoPick(); saveTrip(); } go('#/places'); return; }
    if (act === 'tog') { const i = trip.selected.indexOf(d.id); if (i >= 0) trip.selected.splice(i, 1); else trip.selected.push(d.id); saveTrip(); if (ui.view === 'map' && location.hash === '#/places') { drawPlacesMap(); updatePill(); const sb = $('.sticky-bar'); if (sb) sb.querySelector('b').textContent = trip.selected.length + ' place' + (trip.selected.length === 1 ? '' : 's') + ' selected'; } else refresh(); return; }
    if (act === 'autopick') { autoPick(); saveTrip(); refresh(); toast('Top places selected for your ' + trip.days + ' days'); return; }
    if (act === 'cat') { ui.cat = d.c; refresh(); return; }
    if (act === 'view') { ui.view = d.v; refresh(); return; }
    if (act === 'tier') { ui.tier = d.t; refresh(); return; }
    if (act === 'hotel') { trip.hotel = trip.hotel === d.id ? null : d.id; saveTrip(); refresh(); return; }
    if (act === 'rest') { trip.rest = trip.rest === d.id ? null : d.id; saveTrip(); refresh(); return; }
    if (act === 'photo') { trip.photo = trip.photo === d.id ? null : d.id; saveTrip(); refresh(); return; }
    if (act === 'confirm') { trip.ref = refNo(); trip.bookedAt = Date.now(); saveTrip(); persistTrip(); refresh(); toast('Trip confirmed and saved to My Trips'); return; }
    if (act === 'newbook') { trip.ref = null; saveTrip(); refresh(); return; }
    if (act === 'print') { window.print(); return; }
    if (act === 'open') { const s = store.get(tripsKey(), []).find(x => x.id === d.id); if (s) { trip = s.trip; saveTrip(); go('#/route'); } return; }
    if (act === 'del') { store.set(tripsKey(), store.get(tripsKey(), []).filter(x => x.id !== d.id)); if (localStorage.getItem('matp_token')) TravellerAPI.deleteTrip(d.id).catch(err => console.warn(err.message)); refresh(); return; }
    if (act === 'clear') { const saved = store.get(tripsKey(), []); store.del(tripsKey()); if (localStorage.getItem('matp_token')) saved.forEach(x => TravellerAPI.deleteTrip(x.id).catch(() => {})); toast('Saved trips cleared'); refresh(); return; }
    if (act === 'logout') { logout(); return; }
  });
  document.addEventListener('submit', async e => {
    const f = e.target.closest('[data-form]'); if (!f) return; e.preventDefault(); const k = f.dataset.form;
    if (k === 'login') doLogin(); else if (k === 'signup') doSignup(); else if (k === 'forgot') doForgot();
    else if (k === 'plan') {
      const g = id => $('#' + id).value; const err = m => { $('#perr').textContent = m; };
      const trav = +g('p-trav'), days = +g('p-days'), bud = +g('p-budget');
      if (!(trav >= 1 && trav <= 20)) return err('Travellers must be between 1 and 20.');
      if (!(days >= 1 && days <= 15)) return err('Days must be between 1 and 15.');
      if (!(bud >= 1000)) return err('Please enter a budget of at least ₹1,000.');
      if (!g('p-date')) return err('Please choose a start date.');
      if (g('p-date') < iso(new Date())) return err('Travel date cannot be in the past.');
      const regionChanged = trip.region !== g('p-region'), daysChanged = +trip.days !== days;
      Object.assign(trip, { from: g('p-from'), region: g('p-region'), date: g('p-date'), travellers: trav, days, budget: bud, month: g('p-month'), group: g('p-group'), style: g('p-style'), food: g('p-food'), mode: g('p-mode') });
      if (regionChanged) { trip.hotel = trip.rest = trip.photo = null; }
      if (regionChanged || !trip.selected.length || daysChanged) autoPick();
      ui.tier = null; trip.ref = null; saveTrip(); go('#/places'); toast('Trip saved. Pick your places!');
    } else if (k === 'chpw') {
      const set = m => { $('#perr').textContent = m; };
      const pp = pwProblem($('#cp1').value); if (pp) return set(pp);
      if ($('#cp1').value !== $('#cp2').value) return set('New passwords do not match.');
      try { await TravellerAPI.changePassword({ currentPassword: $('#cp0').value, newPassword: $('#cp1').value }); toast('Password updated'); f.reset(); }
      catch (err) { set(err.message); }
    }
  });
  document.addEventListener('input', e => {
    if (e.target.id === 'q') { ui.q = e.target.value; const pos = e.target.selectionStart; refresh(); const q = $('#q'); if (q) { q.focus(); q.setSelectionRange(pos, pos); } }
    if (e.target.id === 'bud') { const v = +e.target.value; if (v >= 1000) { trip.budget = v; changed(); const y = window.scrollY; render(); window.scrollTo(0, y); const bi = $('#bud'); if (bi) bi.focus(); } }
  });
  document.addEventListener('change', e => {
    if (e.target.id === 'room-count') { trip.roomsSelected = +e.target.value; saveTrip(); refresh(); }
    if (e.target.id === 'p-region2') { trip.region = e.target.value; trip.hotel = trip.rest = trip.photo = null; ui.cat = 'All'; ui.q = ''; autoPick(); saveTrip(); refresh(); }
  });
  window.addEventListener('hashchange', () => { if (user) render(); });
  window.addEventListener('error', ev => console.warn('App error:', ev.message));

  /* ---------- boot ---------- */
  const email = store.get('stp_session', null);
  if (email && users()[email]) { user = { email, name: users()[email].name }; trip = store.get('stp_trip_' + email, null) || defaultTrip(); }
  render();
})();
