/* Multi Agent Traveller Planner - catalogue data (sample data for demonstration) */
const START_CITIES = [
  { n: "Warangal", lat: 17.9689, lng: 79.5941 }, { n: "Hyderabad", lat: 17.385, lng: 78.4867 },
  { n: "Nellore", lat: 14.4426, lng: 79.9865 }, { n: "Visakhapatnam", lat: 17.6868, lng: 83.2185 },
  { n: "Delhi", lat: 28.6139, lng: 77.209 }, { n: "Mumbai", lat: 19.076, lng: 72.8777 },
  { n: "Pune", lat: 18.5204, lng: 73.8567 }, { n: "Bengaluru", lat: 12.9716, lng: 77.5946 },
  { n: "Chennai", lat: 13.0827, lng: 80.2707 }, { n: "Kochi", lat: 9.9312, lng: 76.2673 },
  { n: "Kolkata", lat: 22.5726, lng: 88.3639 }, { n: "Ahmedabad", lat: 23.0225, lng: 72.5714 },
  { n: "Jaipur", lat: 26.9124, lng: 75.7873 }, { n: "Lucknow", lat: 26.8467, lng: 80.9462 },
  { n: "Chandigarh", lat: 30.7333, lng: 76.7794 }
];

// place row: [name, city, lat, lng, fee, timings, bestSeason, category, hours, description, wikipediaTitle]
const RAW = [
  { id: "ap", name: "Andhra Pradesh", emoji: "🛕", cuisine: "Andhra meals and biryani", hero: "Araku Valley", places: [
    ["Tirumala Venkateswara Temple", "Tirupati", 13.6833, 79.3472, 0, "03:00 - 21:00 (queue varies)", "Oct - Feb", "Spiritual", 4, "One of the most visited temples in the world, set on the Tirumala hills.", "Tirumala Venkateswara Temple"],
    ["Araku Valley", "Araku", 18.3273, 82.8759, 0, "Open all day", "Oct - Feb", "Nature", 5, "Coffee plantations and misty hills in the Eastern Ghats.", "Araku Valley"],
    ["Borra Caves", "Araku", 18.28, 83.04, 60, "10:00 - 17:00", "Oct - Mar", "Nature", 2, "Ancient limestone caves with striking stalactites and stalagmites.", "Borra Caves"],
    ["RK Beach", "Visakhapatnam", 17.7142, 83.3231, 0, "Open all day", "Oct - Mar", "Beach", 2, "Popular city beach with a lively evening promenade.", "Ramakrishna Beach"]
  ] },
  { id: "kl", name: "Kerala", emoji: "🌴", cuisine: "Kerala sadya and seafood", hero: "Alappuzha", places: [
    ["Munnar", "Munnar", 10.0889, 77.0595, 0, "Open all day", "Sep - Mar", "Nature", 6, "Rolling tea gardens, waterfalls and cool mountain air.", "Munnar"],
    ["Alleppey Backwaters", "Alappuzha", 9.4981, 76.3388, 0, "Open all day (houseboat extra)", "Nov - Feb", "Nature", 5, "Cruise quiet canals and lagoons in a traditional houseboat.", "Alappuzha"],
    ["Fort Kochi", "Kochi", 9.9658, 76.2421, 0, "Open all day", "Oct - Mar", "Heritage", 3, "Chinese fishing nets, colonial streets and art cafes by the sea.", "Fort Kochi"],
    ["Periyar Tiger Reserve", "Thekkady", 9.4627, 77.237, 300, "06:00 - 17:00", "Oct - May", "Adventure", 4, "Boat safari and forest walks around a scenic lake.", "Periyar National Park"]
  ] },
  { id: "rj", name: "Rajasthan", emoji: "🏰", cuisine: "Dal baati churma and thali", hero: "Amer Fort", places: [
    ["Amber Fort", "Jaipur", 26.9855, 75.8513, 100, "08:00 - 17:30", "Oct - Mar", "Heritage", 3, "Hilltop fort-palace of red sandstone and marble above Maota Lake.", "Amer Fort"],
    ["Hawa Mahal", "Jaipur", 26.9239, 75.8267, 50, "09:00 - 16:30", "Oct - Mar", "Heritage", 1, "The Palace of Winds with its honeycomb pink sandstone facade.", "Hawa Mahal"],
    ["City Palace Udaipur", "Udaipur", 24.5764, 73.6835, 300, "09:30 - 17:30", "Sep - Mar", "Heritage", 3, "A grand palace complex on the banks of Lake Pichola.", "City Palace, Udaipur"],
    ["Mehrangarh Fort", "Jodhpur", 26.2979, 73.0184, 600, "09:00 - 17:00", "Oct - Mar", "Heritage", 3, "One of the largest forts in India, towering above the blue city.", "Mehrangarh"]
  ] },
  { id: "ga", name: "Goa", emoji: "🏖️", cuisine: "Goan seafood and vindaloo", hero: "Baga Beach", places: [
    ["Baga Beach", "Baga", 15.5522, 73.7517, 0, "Open all day", "Nov - Feb", "Beach", 3, "Golden sands, water sports and a famous nightlife strip.", "Baga Beach"],
    ["Basilica of Bom Jesus", "Old Goa", 15.5009, 73.9116, 0, "09:00 - 18:30", "Oct - Mar", "Heritage", 1, "UNESCO World Heritage church holding the relics of St. Francis Xavier.", "Basilica of Bom Jesus"],
    ["Fort Aguada", "Candolim", 15.4925, 73.7737, 25, "09:30 - 18:00", "Oct - Mar", "Heritage", 2, "A 17th century Portuguese fort with a lighthouse and sea views.", "Fort Aguada"],
    ["Dudhsagar Falls", "Mollem", 15.3144, 74.3143, 400, "08:00 - 17:00", "Jun - Dec", "Adventure", 5, "A four-tiered waterfall that looks like a stream of milk.", "Dudhsagar Falls"]
  ] },
  { id: "hp", name: "Himachal Pradesh", emoji: "🏔️", cuisine: "Siddu, dham and momos", hero: "Manali, Himachal Pradesh", places: [
    ["Solang Valley", "Manali", 32.317, 77.158, 0, "Open all day", "Dec - Mar, May - Jun", "Adventure", 4, "Skiing, paragliding and zorbing in a green Himalayan valley.", "Solang Valley"],
    ["Rohtang Pass", "Manali", 32.3716, 77.2466, 550, "07:00 - 17:00 (permit needed)", "May - Oct", "Nature", 6, "High mountain pass with snow views and glaciers.", "Rohtang Pass"],
    ["The Ridge Shimla", "Shimla", 31.1048, 77.1734, 0, "Open all day", "Mar - Jun, Dec", "City", 2, "Open promenade with colonial buildings and Himalayan views.", "The Ridge, Shimla"],
    ["Hadimba Temple", "Manali", 32.248, 77.18, 0, "08:00 - 18:00", "Mar - Oct", "Spiritual", 1, "Wooden cave temple surrounded by tall deodar forest.", "Hidimba Devi Temple"]
  ] },
  { id: "tn", name: "Tamil Nadu", emoji: "🛕", cuisine: "Chettinad food and filter coffee", hero: "Meenakshi Temple", places: [
    ["Meenakshi Temple", "Madurai", 9.9195, 78.1193, 0, "05:00 - 22:00", "Oct - Mar", "Spiritual", 3, "A colourful Dravidian temple complex with towering gopurams.", "Meenakshi Temple"],
    ["Marina Beach", "Chennai", 13.05, 80.2824, 0, "Open all day", "Nov - Feb", "Beach", 2, "One of the longest urban beaches in the world.", "Marina Beach"],
    ["Brihadisvara Temple", "Thanjavur", 10.7828, 79.1318, 0, "06:00 - 20:30", "Oct - Mar", "Heritage", 2, "A UNESCO listed Chola temple built a thousand years ago.", "Brihadisvara Temple, Thanjavur"],
    ["Shore Temple", "Mahabalipuram", 12.6167, 80.193, 40, "06:00 - 18:00", "Nov - Feb", "Heritage", 2, "Seaside granite temple from the Pallava dynasty.", "Shore Temple"],
    ["Ooty", "Ooty", 11.4102, 76.695, 0, "Open all day", "Mar - Jun, Sep - Nov", "Nature", 6, "A hill station with tea gardens, a lake and a toy train.", "Ooty"]
  ] },
  { id: "ka", name: "Karnataka", emoji: "👑", cuisine: "Dosa, bisi bele bath and Mysore pak", hero: "Mysore Palace", places: [
    ["Mysore Palace", "Mysuru", 12.3052, 76.6552, 100, "10:00 - 17:30", "Oct - Mar", "Heritage", 3, "A royal palace that glows with thousands of lights on weekends.", "Mysore Palace"],
    ["Hampi", "Hampi", 15.335, 76.46, 40, "06:00 - 18:00", "Oct - Feb", "Heritage", 6, "Ruins of the Vijayanagara empire spread across boulder hills.", "Hampi"],
    ["Lalbagh Botanical Garden", "Bengaluru", 12.9507, 77.5848, 30, "06:00 - 19:00", "Year round", "Nature", 2, "A historic garden with a glasshouse and rare trees.", "Lal Bagh"],
    ["Gol Gumbaz", "Vijayapura", 16.8302, 75.7358, 25, "06:00 - 18:00", "Oct - Mar", "Heritage", 2, "A massive domed mausoleum with a famous whispering gallery.", "Gol Gumbaz"]
  ] },
  { id: "up", name: "Uttar Pradesh", emoji: "🕌", cuisine: "Chaat, kebabs and petha", hero: "Taj Mahal", places: [
    ["Taj Mahal", "Agra", 27.1751, 78.0421, 1100, "06:00 - 18:30 (closed Friday)", "Oct - Mar", "Heritage", 3, "The white marble monument of love and a wonder of the world.", "Taj Mahal"],
    ["Agra Fort", "Agra", 27.1795, 78.0211, 650, "06:00 - 18:00", "Oct - Mar", "Heritage", 3, "A red sandstone Mughal fort with views of the Taj Mahal.", "Agra Fort"],
    ["Fatehpur Sikri", "Fatehpur Sikri", 27.094, 77.6611, 610, "06:00 - 18:00", "Oct - Mar", "Heritage", 3, "An abandoned Mughal capital of sandstone palaces.", "Fatehpur Sikri"],
    ["Varanasi Ghats", "Varanasi", 25.3109, 83.0107, 0, "Open all day", "Oct - Mar", "Spiritual", 4, "Riverfront steps on the Ganga with the famous evening aarti.", "Ghats in Varanasi"]
  ] },
  { id: "mh", name: "Maharashtra", emoji: "🌆", cuisine: "Vada pav, misal and puran poli", hero: "Gateway of India", places: [
    ["Gateway of India", "Mumbai", 18.922, 72.8347, 0, "Open all day", "Nov - Feb", "City", 1, "A grand waterfront arch and the symbol of Mumbai.", "Gateway of India"],
    ["Ajanta Caves", "Aurangabad", 20.5519, 75.7033, 40, "09:00 - 17:00 (closed Monday)", "Oct - Mar", "Heritage", 4, "Rock-cut Buddhist caves with ancient paintings.", "Ajanta Caves"],
    ["Ellora Caves", "Aurangabad", 20.0258, 75.178, 40, "06:00 - 18:00 (closed Tuesday)", "Oct - Mar", "Heritage", 4, "Rock-cut temples carved from a single basalt cliff.", "Ellora Caves"],
    ["Shaniwar Wada", "Pune", 18.5195, 73.8553, 25, "08:00 - 18:00", "Oct - Feb", "Heritage", 2, "A historic fortification of the Peshwa rulers.", "Shaniwar Wada"]
  ] },
  { id: "wb", name: "West Bengal", emoji: "🌉", cuisine: "Fish curry and sweets", hero: "Victoria Memorial, Kolkata", places: [
    ["Victoria Memorial", "Kolkata", 22.5448, 88.3426, 30, "10:00 - 17:00 (closed Monday)", "Oct - Mar", "Heritage", 2, "A white marble monument and museum set in landscaped gardens.", "Victoria Memorial, Kolkata"],
    ["Howrah Bridge", "Kolkata", 22.5851, 88.3468, 0, "Open all day", "Oct - Mar", "City", 1, "A busy cantilever bridge that is an icon of Kolkata.", "Howrah Bridge"],
    ["Darjeeling", "Darjeeling", 27.036, 88.2627, 0, "Open all day", "Mar - May, Oct - Nov", "Nature", 6, "Tea estates, a toy train and sunrise views of Kanchenjunga.", "Darjeeling"],
    ["Sundarbans", "Sundarbans", 21.9497, 89.1833, 500, "06:00 - 17:00", "Nov - Feb", "Adventure", 6, "The world's largest mangrove forest and home of the Bengal tiger.", "Sundarbans"]
  ] },
  { id: "dl", name: "Delhi", emoji: "🏛️", cuisine: "Chole bhature and kebabs", hero: "India Gate", places: [
    ["Red Fort", "Delhi", 28.6562, 77.241, 35, "09:30 - 16:30 (closed Monday)", "Oct - Mar", "Heritage", 2, "The Mughal fort from where the Prime Minister addresses the nation.", "Red Fort"],
    ["India Gate", "Delhi", 28.6129, 77.2295, 0, "Open all day", "Oct - Mar", "City", 1, "A war memorial arch with lawns that are lovely at night.", "India Gate"],
    ["Qutub Minar", "Delhi", 28.5244, 77.1855, 40, "07:00 - 17:00", "Oct - Mar", "Heritage", 2, "A 73 metre tall brick minaret from the 12th century.", "Qutb Minar"],
    ["Humayun's Tomb", "Delhi", 28.5933, 77.2507, 40, "06:00 - 18:00", "Oct - Mar", "Heritage", 2, "A garden tomb that inspired the design of the Taj Mahal.", "Humayun's Tomb"]
  ] },
  { id: "jk", name: "Jammu, Kashmir and Ladakh", emoji: "❄️", cuisine: "Wazwan and kahwa", hero: "Dal Lake", places: [
    ["Dal Lake", "Srinagar", 34.117, 74.867, 0, "Open all day (shikara extra)", "Apr - Oct", "Nature", 4, "Shikara rides and floating gardens among houseboats.", "Dal Lake"],
    ["Gulmarg", "Gulmarg", 34.0484, 74.3805, 0, "Open all day (gondola extra)", "Dec - Mar, May - Sep", "Adventure", 6, "A meadow resort with one of the highest gondolas in the world.", "Gulmarg"],
    ["Pangong Lake", "Leh", 33.7595, 78.6674, 400, "Open all day (permit needed)", "May - Sep", "Nature", 8, "A high-altitude lake that changes colour through the day.", "Pangong Tso"],
    ["Leh Palace", "Leh", 34.165, 77.584, 15, "07:00 - 16:00", "May - Sep", "Heritage", 2, "A nine storey royal palace overlooking Leh town.", "Leh Palace"]
  ] },
  { id: "uk", name: "Uttarakhand", emoji: "🧘", cuisine: "Aloo ke gutke and bal mithai", hero: "Rishikesh", places: [
    ["Laxman Jhula", "Rishikesh", 30.126, 78.329, 0, "Open all day", "Sep - Jun", "Spiritual", 2, "An iron suspension bridge across the Ganga with ashrams and cafes.", "Lakshman Jhula"],
    ["Har Ki Pauri", "Haridwar", 29.9546, 78.1693, 0, "Open all day", "Oct - Mar", "Spiritual", 2, "The sacred ghat famous for its grand evening Ganga aarti.", "Har Ki Pauri"],
    ["Naini Lake", "Nainital", 29.3919, 79.4542, 0, "Open all day", "Mar - Jun, Sep - Nov", "Nature", 3, "A crescent shaped lake with boating and a hill town around it.", "Naini Lake"],
    ["Valley of Flowers", "Joshimath", 30.728, 79.605, 150, "07:00 - 17:00", "Jul - Sep", "Adventure", 8, "A high-altitude valley of alpine blooms and a trekking favourite.", "Valley of Flowers National Park"]
  ] },
  { id: "tg", name: "Telangana", emoji: "🕌", cuisine: "Hyderabadi biryani and irani chai", hero: "Charminar", places: [
    ["Charminar", "Hyderabad", 17.3616, 78.4747, 25, "09:30 - 17:30", "Oct - Feb", "Heritage", 2, "The 16th century monument surrounded by pearl and bangle bazaars.", "Charminar"],
    ["Golconda Fort", "Hyderabad", 17.3833, 78.4011, 25, "09:00 - 17:30", "Oct - Feb", "Heritage", 3, "A fort with remarkable acoustics and a evening sound-and-light show.", "Golconda"],
    ["Ramoji Film City", "Hyderabad", 17.2543, 78.6808, 1350, "09:00 - 17:30", "Oct - Mar", "Adventure", 7, "The world's largest film studio complex with sets and rides.", "Ramoji Film City"],
    ["Hussain Sagar Lake", "Hyderabad", 17.4239, 78.4738, 0, "Open all day", "Oct - Feb", "City", 2, "A heart-shaped lake with a giant Buddha statue in the middle.", "Hussain Sagar"]
  ] }
];


// Expanded worldwide catalogue (illustrative destination listings; use global search for any other place).
RAW.push(
  { id:"fr", name:"France", emoji:"🇫🇷", cuisine:"French pastries, crepes and regional cuisine", hero:"Paris", places:[
    ["Eiffel Tower","Paris",48.8584,2.2945,1800,"09:30 - 23:45","Apr - Oct","Heritage",3,"Iconic iron tower with city views.","Eiffel Tower"],
    ["Louvre Museum","Paris",48.8606,2.3376,2200,"09:00 - 18:00 (closed Tuesday)","Year round","Heritage",4,"World-famous art museum.","Louvre Museum"],
    ["Palace of Versailles","Versailles",48.8049,2.1204,2400,"09:00 - 18:30 (closed Monday)","Apr - Oct","Heritage",5,"Grand royal palace and gardens.","Palace of Versailles"],
    ["Promenade des Anglais","Nice",43.6952,7.2650,0,"Open all day","May - Sep","Beach",2,"Seafront promenade on the French Riviera.","Promenade des Anglais"]
  ]},
  { id:"it", name:"Italy", emoji:"🇮🇹", cuisine:"Pizza, pasta and gelato", hero:"Colosseum", places:[
    ["Colosseum","Rome",41.8902,12.4922,1800,"08:30 - 16:30","Apr - Oct","Heritage",3,"Ancient Roman amphitheatre.","Colosseum"],
    ["Trevi Fountain","Rome",41.9009,12.4833,0,"Open all day","Year round","City",1,"Baroque fountain in central Rome.","Trevi Fountain"],
    ["Canals of Venice","Venice",45.4408,12.3155,0,"Open all day","Apr - Oct","City",4,"Historic canals and bridges.","Venice"],
    ["Duomo di Milano","Milan",45.4642,9.1916,900,"09:00 - 19:00","Year round","Heritage",2,"Gothic cathedral in Milan.","Milan Cathedral"]
  ]},
  { id:"ukg", name:"United Kingdom", emoji:"🇬🇧", cuisine:"Fish and chips, pies and afternoon tea", hero:"Big Ben", places:[
    ["Big Ben and Westminster","London",51.5007,-0.1246,0,"Exterior open all day","May - Sep","Heritage",2,"Landmark clock tower beside Parliament.","Big Ben"],
    ["Tower of London","London",51.5081,-0.0759,2200,"09:00 - 17:30","Mar - Oct","Heritage",3,"Historic castle and Crown Jewels.","Tower of London"],
    ["Edinburgh Castle","Edinburgh",55.9486,-3.1999,2100,"09:30 - 17:00","May - Sep","Heritage",3,"Castle overlooking the Scottish capital.","Edinburgh Castle"],
    ["Stonehenge","Wiltshire",51.1789,-1.8262,2600,"09:30 - 17:00","Apr - Sep","Heritage",3,"Prehistoric stone circle.","Stonehenge"]
  ]},
  { id:"ch", name:"Switzerland", emoji:"🇨🇭", cuisine:"Fondue, rösti and chocolate", hero:"Matterhorn", places:[
    ["Matterhorn Viewpoint","Zermatt",45.9763,7.6586,4500,"Cable car hours vary","Jun - Sep","Nature",5,"Iconic alpine peak and mountain views.","Matterhorn"],
    ["Chapel Bridge","Lucerne",47.0517,8.3073,0,"Open all day","Year round","Heritage",1,"Covered wooden bridge across the Reuss.","Chapel Bridge"],
    ["Lake Geneva","Geneva",46.2044,6.1432,0,"Open all day","May - Sep","Nature",3,"Large lake with waterfront promenades.","Lake Geneva"]
  ]},
  { id:"jp", name:"Japan", emoji:"🇯🇵", cuisine:"Sushi, ramen and tempura", hero:"Mount Fuji", places:[
    ["Senso-ji Temple","Tokyo",35.7148,139.7967,0,"06:00 - 17:00","Mar - May","Spiritual",2,"Historic Buddhist temple in Asakusa.","Sensō-ji"],
    ["Shibuya Crossing","Tokyo",35.6595,139.7005,0,"Open all day","Year round","City",1,"Famous pedestrian crossing.","Shibuya Crossing"],
    ["Fushimi Inari Shrine","Kyoto",34.9671,135.7727,0,"Open all day","Mar - May","Spiritual",3,"Mountain shrine known for thousands of torii gates.","Fushimi Inari-taisha"],
    ["Mount Fuji","Fujinomiya",35.3606,138.7274,0,"Climbing season varies","Jul - Sep","Nature",6,"Japan's iconic mountain.","Mount Fuji"]
  ]},
  { id:"ae", name:"United Arab Emirates", emoji:"🇦🇪", cuisine:"Emirati dishes and Middle Eastern food", hero:"Burj Khalifa", places:[
    ["Burj Khalifa","Dubai",25.1972,55.2744,3000,"10:00 - 23:00","Nov - Mar","City",2,"Observation decks in the world's tallest building.","Burj Khalifa"],
    ["Dubai Marina","Dubai",25.0805,55.1403,0,"Open all day","Nov - Mar","City",2,"Waterfront district with restaurants and promenades.","Dubai Marina"],
    ["Sheikh Zayed Grand Mosque","Abu Dhabi",24.4128,54.4749,0,"Visiting hours vary","Nov - Mar","Spiritual",2,"Grand white-marble mosque.","Sheikh Zayed Grand Mosque"]
  ]},
  { id:"th", name:"Thailand", emoji:"🇹🇭", cuisine:"Pad thai, curry and mango sticky rice", hero:"Grand Palace Bangkok", places:[
    ["Grand Palace","Bangkok",13.7500,100.4913,1200,"08:30 - 15:30","Nov - Feb","Heritage",3,"Historic royal complex.","Grand Palace"],
    ["Wat Arun","Bangkok",13.7437,100.4889,400,"08:00 - 18:00","Nov - Feb","Spiritual",2,"Temple of Dawn beside the Chao Phraya River.","Wat Arun"],
    ["Railay Beach","Krabi",8.0113,98.8372,0,"Open all day","Nov - Apr","Beach",4,"Limestone cliffs and clear water.","Railay Beach"]
  ]},
  { id:"sg", name:"Singapore", emoji:"🇸🇬", cuisine:"Hawker food, laksa and chilli crab", hero:"Gardens by the Bay", places:[
    ["Gardens by the Bay","Singapore",1.2816,103.8636,2200,"09:00 - 21:00","Year round","Nature",3,"Futuristic gardens and Supertree Grove.","Gardens by the Bay"],
    ["Marina Bay Sands SkyPark","Singapore",1.2834,103.8607,2500,"10:00 - 22:00","Year round","City",2,"Observation deck above Marina Bay.","Marina Bay Sands"],
    ["Sentosa Island","Singapore",1.2494,103.8303,0,"Open all day","Year round","Beach",5,"Island resort with beaches and attractions.","Sentosa"]
  ]},
  { id:"us", name:"United States", emoji:"🇺🇸", cuisine:"Regional American food", hero:"Statue of Liberty", places:[
    ["Statue of Liberty","New York",40.6892,-74.0445,2500,"Ferry schedule varies","Apr - Oct","Heritage",4,"Harbour monument and national landmark.","Statue of Liberty"],
    ["Central Park","New York",40.7829,-73.9654,0,"06:00 - 01:00","Apr - Oct","Nature",3,"Large urban park in Manhattan.","Central Park"],
    ["Golden Gate Bridge","San Francisco",37.8199,-122.4783,0,"Open all day","Apr - Oct","City",2,"Iconic suspension bridge.","Golden Gate Bridge"],
    ["Grand Canyon South Rim","Arizona",36.0544,-112.1401,0,"Open all day","Mar - May","Nature",6,"Vast canyon landscape.","Grand Canyon"]
  ]},
  { id:"au", name:"Australia", emoji:"🇦🇺", cuisine:"Barbecue, seafood and meat pies", hero:"Sydney Opera House", places:[
    ["Sydney Opera House","Sydney",-33.8568,151.2153,0,"Tours daily","Sep - Nov","Heritage",2,"Performing arts landmark on the harbour.","Sydney Opera House"],
    ["Bondi Beach","Sydney",-33.8915,151.2767,0,"Open all day","Sep - Apr","Beach",3,"Popular surf beach.","Bondi Beach"],
    ["Great Ocean Road","Victoria",-38.6800,143.3900,0,"Open all day","Dec - Feb","Nature",8,"Scenic coastal road and rock formations.","Great Ocean Road"],
    ["Uluru","Northern Territory",-25.3444,131.0369,0,"Park hours vary","May - Sep","Nature",5,"Sacred sandstone monolith.","Uluru"]
  ]},
  { id:"za", name:"South Africa", emoji:"🇿🇦", cuisine:"Braai and Cape Malay cuisine", hero:"Table Mountain", places:[
    ["Table Mountain","Cape Town",-33.9628,18.4098,2500,"Cableway hours vary","Nov - Mar","Nature",4,"Flat-topped mountain above Cape Town.","Table Mountain"],
    ["V&A Waterfront","Cape Town",-33.9036,18.4208,0,"Open all day","Nov - Mar","City",3,"Harbour district with shops and restaurants.","Victoria & Alfred Waterfront"],
    ["Kruger National Park","Mpumalanga",-23.9884,31.5547,800,"05:30 - 18:00","May - Sep","Adventure",8,"Wildlife reserve and safari destination.","Kruger National Park"]
  ]},
  { id:"br", name:"Brazil", emoji:"🇧🇷", cuisine:"Feijoada, pão de queijo and barbecue", hero:"Christ the Redeemer", places:[
    ["Christ the Redeemer","Rio de Janeiro",-22.9519,-43.2105,1800,"08:00 - 19:00","May - Oct","Heritage",3,"Hilltop statue overlooking Rio.","Christ the Redeemer"],
    ["Copacabana Beach","Rio de Janeiro",-22.9711,-43.1822,0,"Open all day","Dec - Mar","Beach",3,"Famous crescent-shaped city beach.","Copacabana"]
  ]}
);

const TIERS = {
  "Low Budget": { stay: 850, meal: 250 },
  Normal: { stay: 1400, meal: 450 },
  Premium: { stay: 3900, meal: 900 },
  Luxury: { stay: 9000, meal: 1800 } // retained for older saved trips
};

function hashStr(s) { let h = 7; for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0; return h; }

const REGIONS = RAW.map(r => {
  const places = r.places.map((p, i) => ({
    id: r.id + (i + 1), region: r.id, name: p[0], city: p[1], lat: p[2], lng: p[3], fee: p[4],
    time: p[5], season: p[6], cat: p[7], hrs: p[8], desc: p[9], wiki: p[10]
  }));
  const cities = [...new Set(places.map(p => p.city))];
  const c = i => cities[i % cities.length];
  const mk = (tier, name, i, base) => {
    const h = hashStr(name);
    return { id: r.id + "-h-" + tier.replace(/\s/g, "")[0] + i, region: r.id, tier, name, availableRooms: 3 + (h % 9), city: c(i + (tier === "Normal" ? 0 : tier === "Premium" ? 1 : 2)),
      price: Math.round(base * (0.9 + (h % 30) / 100) / 50) * 50, rating: (3.9 + (h % 10) / 10).toFixed(1) };
  };
  const hotels = [];
  ["Low Budget", "Normal", "Premium"].forEach(t => {
    const names = t === "Low Budget" ? ["Budget Lodge", "Comfort Inn"] : t === "Normal" ? ["Residency", "City Inn"] : ["Grand Plaza", "Heritage Stay"];
    names.forEach((n, i) => {
      const city = c(i + (t === "Low Budget" ? 0 : t === "Normal" ? 1 : 2));
      const nm = n === "Comfort Inn" ? city + " Comfort Inn" : n === "Heritage Stay" ? "The " + city + " Heritage" : n === "Residency" ? "Hotel " + city + " Residency" : n === "City Inn" ? city + " City Inn" : city + " " + n;
      const h = mk(t, nm, i, TIERS[t].stay); h.city = city; hotels.push(h);
    });
  });
  const rest = [
    { n: (c(0)) + " Thali House", type: "Veg", price: 380, cuisine: r.cuisine },
    { n: (c(1)) + " Spice Route", type: "Both", price: 520, cuisine: "Local and North Indian" },
    { n: (c(0)) + " Biryani and Grill", type: "Non-Veg", price: 620, cuisine: "Grills and biryani" },
    { n: "Sattvik " + (c(2)) + " Cafe", type: "Veg", price: 420, cuisine: "Cafe and snacks" }
  ].map((x, i) => ({ id: r.id + "-r" + i, region: r.id, name: x.n, type: x.type, price: x.price, cuisine: x.cuisine, rating: (3.9 + (hashStr(x.n) % 10) / 10).toFixed(1) }));
  const photos = [
    { id: r.id + "-p0", region: r.id, name: c(0) + " Lens Studio", style: "Travel and portraits", hour: 1200, day: 7500, rating: "4.7" },
    { id: r.id + "-p1", region: r.id, name: "Wanderframe " + c(1), style: "Candid and couple shoots", hour: 1800, day: 11000, rating: "4.8" }
  ];
  return { id: r.id, name: r.name, emoji: r.emoji, cuisine: r.cuisine, hero: r.hero, places, hotels, rest, photos, cities };
});

const CATEGORIES = ["All", "Heritage", "Nature", "Beach", "Spiritual", "Adventure", "City"];
const CAT_EMOJI = { Heritage: "🏰", Nature: "🌿", Beach: "🏖️", Spiritual: "🛕", Adventure: "🧗", City: "🏙️" };
