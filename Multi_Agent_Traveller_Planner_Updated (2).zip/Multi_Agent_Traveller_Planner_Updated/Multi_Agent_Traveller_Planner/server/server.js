require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const rateLimit = require('express-rate-limit');

const app = express();
const PORT = Number(process.env.PORT) || 5000;
const JWT_SECRET = process.env.JWT_SECRET || 'development-only-change-this-secret';
const DATA_DIR = path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'database.json');
fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(DB_FILE)) fs.writeFileSync(DB_FILE, JSON.stringify({ users: [], trips: [] }, null, 2));

function readDB() {
  try { return JSON.parse(fs.readFileSync(DB_FILE, 'utf8')); }
  catch (error) { console.error('Could not read database:', error); return { users: [], trips: [] }; }
}
function writeDB(db) {
  const temp = DB_FILE + '.tmp';
  fs.writeFileSync(temp, JSON.stringify(db, null, 2));
  fs.renameSync(temp, DB_FILE);
}
const cleanUser = user => ({ id: user.id, name: user.name, email: user.email, createdAt: user.createdAt });
const makeToken = user => jwt.sign({ sub: user.id, email: user.email }, JWT_SECRET, { expiresIn: '7d' });
const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: 'draft-7', legacyHeaders: false, message: { message: 'Too many attempts. Please try again in 15 minutes.' } });
app.use(cors());
app.use(express.json({ limit: '1mb' }));
app.use('/api/auth', authLimiter);

function requireAuth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : '';
  if (!token) return res.status(401).json({ message: 'Please log in to continue.' });
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    const db = readDB();
    const user = db.users.find(item => item.id === payload.sub);
    if (!user) return res.status(401).json({ message: 'Account not found. Please log in again.' });
    req.user = user;
    next();
  } catch (_) { return res.status(401).json({ message: 'Your session expired. Please log in again.' }); }
}
function validEmail(email) { return typeof email === 'string' && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email); }
function validPassword(password) { return typeof password === 'string' && password.length >= 8 && /[A-Za-z]/.test(password) && /\d/.test(password); }

app.get('/api/health', (_req, res) => res.json({ status: 'ok', service: 'Multi Agent Traveller Planner API' }));

app.post('/api/auth/signup', async (req, res) => {
  try {
    const { name, email, password, securityQuestion, securityAnswer } = req.body || {};
    const normalizedEmail = String(email || '').trim().toLowerCase();
    if (!name || String(name).trim().length < 2) return res.status(400).json({ message: 'Please enter your full name.' });
    if (!validEmail(normalizedEmail)) return res.status(400).json({ message: 'Please enter a valid email address.' });
    if (!validPassword(password)) return res.status(400).json({ message: 'Password must be at least 8 characters and contain a letter and a number.' });
    if (!securityQuestion || !securityAnswer || String(securityAnswer).trim().length < 2) return res.status(400).json({ message: 'Choose a security question and provide an answer.' });
    const db = readDB();
    if (db.users.some(user => user.email === normalizedEmail)) return res.status(409).json({ message: 'An account with this email already exists. Please log in.' });
    const user = {
      id: require('crypto').randomUUID(), name: String(name).trim(), email: normalizedEmail,
      passwordHash: await bcrypt.hash(password, 12), securityQuestion: String(securityQuestion),
      securityAnswerHash: await bcrypt.hash(String(securityAnswer).trim().toLowerCase(), 12), createdAt: new Date().toISOString()
    };
    db.users.push(user); writeDB(db);
    return res.status(201).json({ message: 'Account created successfully.', token: makeToken(user), user: cleanUser(user) });
  } catch (error) { console.error(error); return res.status(500).json({ message: 'Could not create account.' }); }
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const email = String(req.body?.email || '').trim().toLowerCase();
    const password = req.body?.password;
    if (!validEmail(email) || !password) return res.status(400).json({ message: 'Enter a valid email and password.' });
    const user = readDB().users.find(item => item.email === email);
    if (!user || !(await bcrypt.compare(password, user.passwordHash))) return res.status(401).json({ message: 'Incorrect email or password.' });
    return res.json({ message: 'Login successful.', token: makeToken(user), user: cleanUser(user) });
  } catch (error) { console.error(error); return res.status(500).json({ message: 'Could not log in.' }); }
});

app.get('/api/auth/security-question', (req, res) => {
  const email = String(req.query.email || '').trim().toLowerCase();
  if (!validEmail(email)) return res.status(400).json({ message: 'Enter a valid email address.' });
  const user = readDB().users.find(item => item.email === email);
  if (!user) return res.status(404).json({ message: 'No account found for this email.' });
  return res.json({ securityQuestion: user.securityQuestion });
});

app.post('/api/auth/forgot-password', async (req, res) => {
  try {
    const email = String(req.body?.email || '').trim().toLowerCase();
    const answer = String(req.body?.securityAnswer || '').trim().toLowerCase();
    const newPassword = req.body?.newPassword;
    if (!validPassword(newPassword)) return res.status(400).json({ message: 'New password must be at least 8 characters and contain a letter and a number.' });
    const db = readDB(); const user = db.users.find(item => item.email === email);
    if (!user) return res.status(404).json({ message: 'No account found for this email.' });
    if (!(await bcrypt.compare(answer, user.securityAnswerHash))) return res.status(400).json({ message: 'Security answer is not correct.' });
    user.passwordHash = await bcrypt.hash(newPassword, 12); writeDB(db);
    return res.json({ message: 'Password updated successfully.' });
  } catch (error) { console.error(error); return res.status(500).json({ message: 'Could not reset password.' }); }
});

app.post('/api/auth/change-password', requireAuth, async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body || {};
    if (!(await bcrypt.compare(String(currentPassword || ''), req.user.passwordHash))) return res.status(400).json({ message: 'Current password is incorrect.' });
    if (!validPassword(newPassword)) return res.status(400).json({ message: 'New password must be at least 8 characters and contain a letter and a number.' });
    const db = readDB(); const user = db.users.find(item => item.id === req.user.id);
    user.passwordHash = await bcrypt.hash(newPassword, 12); writeDB(db);
    return res.json({ message: 'Password updated successfully.' });
  } catch (error) { console.error(error); return res.status(500).json({ message: 'Could not update password.' }); }
});

app.get('/api/auth/me', requireAuth, (req, res) => res.json({ user: cleanUser(req.user) }));

app.get('/api/trips', requireAuth, (req, res) => {
  const trips = readDB().trips.filter(item => item.userId === req.user.id).sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
  res.json({ trips: trips.map(item => ({ id: item.id, ref: item.trip.ref || null, title: item.title, created: Date.parse(item.createdAt), total: item.total, trip: item.trip })) });
});

app.post('/api/trips', requireAuth, (req, res) => {
  const trip = req.body?.trip;
  if (!trip || typeof trip !== 'object' || Array.isArray(trip)) return res.status(400).json({ message: 'A valid trip object is required.' });
  const db = readDB();
  const id = String(trip.ref || 'draft-' + req.user.id);
  const index = db.trips.findIndex(item => item.userId === req.user.id && item.id === id);
  const now = new Date().toISOString();
  const title = `${String(trip.from || 'Origin')} → ${String(trip.region || 'Destination')} · ${Number(trip.days) || 1} days`;
  const record = { id, userId: req.user.id, title, total: Number(req.body.total) || 0, trip, createdAt: index >= 0 ? db.trips[index].createdAt : now, updatedAt: now };
  if (index >= 0) db.trips[index] = record; else db.trips.push(record);
  writeDB(db);
  res.status(201).json({ message: 'Trip saved.', id });
});

app.delete('/api/trips/:id', requireAuth, (req, res) => {
  const db = readDB(); const before = db.trips.length;
  db.trips = db.trips.filter(item => !(item.userId === req.user.id && item.id === req.params.id));
  writeDB(db);
  if (before === db.trips.length) return res.status(404).json({ message: 'Trip not found.' });
  res.json({ message: 'Trip deleted.' });
});

// Keep database and server implementation files private from static-file requests.
app.use('/server', (_req, res) => res.status(404).json({ message: 'Not found.' }));
// Serve the existing frontend from the same origin so no CORS setup is needed for normal use.
app.use(express.static(path.join(__dirname, '..')));
app.get('*', (req, res, next) => {
  if (req.path.startsWith('/api/')) return next();
  res.sendFile(path.join(__dirname, '..', 'index.html'));
});
app.use((err, _req, res, _next) => { console.error(err); res.status(500).json({ message: 'Unexpected server error.' }); });
app.listen(PORT, () => console.log(`Multi Agent Traveller Planner running at http://localhost:${PORT}`));
